<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>Login</title>

	<!-- Bootstrap -->
	<link href="<?php echo base_url("assets/css/bootstrap.min.css") ?>" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@600&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url("assets/font-awesome-4.7.0/css/font-awesome.css") ?>">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/css/inadmin.css") ?>">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-sm-4 col-sm-offset-4">
				<div class="panel panel-default" style="margin-top: 65px; background-color: darkslategrey;" >
					<div class="panel-body">
						<img src="<?php echo base_url("assets/img/halo/logo6.png") ?>" height="150px" alt="" class="img-rounded" style="display: block; margin: auto;">
						<h3 class="text-center" style="color: white;">SMA Taman Madya Jetis Yogyakarta</h3>
						<p class="text-center" style="color: white;">Taqwa, cerdas, terampil, sehat, merdeka, mandiri dan berbudi pekerti luhur.</p>
						<hr>
						<!--<p class="text-center">WELCOME</p>-->
						<form method="post">
							<div class="form-group">
								<!--<label>ID Akun</label>-->
								<input type="text" name="id_akun" class="form-control" value="<?php echo set_value('id_akun') ?>" placeholder="Username/Email">
								<p><small><i class="text-danger"><?php echo form_error('id_akun') ?></i></small></p>
							</div>

							<div class="form-group">
								<!--<label>Kata Sandi</label>-->
								<input type="Password" name="kata_sandi" class="form-control" value="<?php echo set_value('kata_sandi')?>" placeholder="Kata Sandi">
								<p><small><i class="text-danger"><?php echo form_error('kata_sandi') ?></i></small></p>
							</div>

							<div class="form-group">
								<button class="btn btn-primary" style="border-radius: 20px;"><i class="fa fa-unlock-alt"></i> Masuk</button>
							</div>
						</form>
					</div>
				</div>
				<?php echo $this->session->flashdata('gagal'); ?>
			</div>
		</div>
	</div>
	<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
	<!-- Include all compiled plugins (below), or include individual files as needed -->
	<script src="<?php echo base_url("assets/js/bootstrap.min.js") ?>"></script>
</body>
</html>