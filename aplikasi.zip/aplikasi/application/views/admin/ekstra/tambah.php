<h3>Tambah Data Ekstrakurikuler</h3>
<hr>
<form method="post">
	<div class="form-group">
		<label>Nama Ekstrakurikuler</label>
		<input type="text" name="nama_ekstra" class="form-control" value="<?php echo set_value('nama_ekstra') ?>">
		<p><small><i class="text-danger"><?php echo form_error("nama_ekstra") ?></i></small></p>
	</div>

<div class="form-group">
		<label>Keterangan Ekstrakurikuler</label>
		<select name="keterangan_ekstra" class="form-control">
			<option value="">Pilih</option>
			<option value="Aktif">Aktif</option>
			<option value="Tidak Aktif">Tidak aktif</option>
		</select>
	</div>

<div class="form-group">
	<button class="btn btn-primary">SIMPAN</button>
	<a href="<?php echo base_url("admin/ekstra") ?>" class="btn btn-warning">Kembali</a>
</div>
</form>