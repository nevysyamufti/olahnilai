<h3>UBAH DATA EKSTRAKURIKULER</h3>
<hr>
<form method="post">
<div class="form-group">
		<label>Nama Ekstrakurikuler</label>
		<input type="" name="nama_ekstra" class="form-control" value="<?php echo set_value("nama_ekstra", $detail['nama_ekstra']) ?>">
		<p><small><i class="text-danger"><?php echo form_error("nama_ekstra") ?></i></small></p>
	</div>
<div class="form-group">
		<label>Keterangan Ekstrakurikuler</label>
		<select name="keterangan_ekstra" class="form-group" value="<?php echo set_value("keterangan_ekstra", $detail['keterangan_ekstra']) ?>">
			<option value="Aktif" <?php if($detail['keterangan_ekstra']=="Aktif"){echo"selected";} ?>>Aktif</option>
			<option value="Tidak Aktif" <?php if($detail['keterangan_ekstra']=="Tidak Aktif"){echo"selected";} ?>>Tidak Aktif</option>
		</select>
	</div>

	<div class="form-group">
		<button class="btn btn-primary">Simpan</button>
		<a href="<?php echo base_url("admin/ekstra") ?>" class="btn btn-warning">Kembali</a>
	</div>
</form>