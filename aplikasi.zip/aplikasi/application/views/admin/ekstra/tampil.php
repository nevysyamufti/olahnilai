<h3>DATA EKSTRAKURIKULER</h3>
<hr>
<div class="table table-responsive">
	<table class="table table-bordered" id="thetable">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama Ekstrakurikuler</th>
				<th>Keterangan Ekstrakurikuler</th>
				<th>Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($ekstra as $key => $value): ?>
				<tr>
					<td><?php echo $key+1 ?></td>
					<td><?php echo $value['nama_ekstra'] ?></td>
					<td><?php echo $value['keterangan_ekstra'] ?></td>
					<td>
						<a href="<?php echo base_url("admin/ekstra/ubah/".$value['id_ekstra']) ?>" class="btn btn-warning">Ubah</a>
						<a href="<?php echo base_url("admin/ekstra/hapus/".$value['id_ekstra']) ?>" class="btn btn-danger" onclick="return confirm('apakah yakin menghapus ?')">Hapus</a>
					</td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>
</div>
<div>
	<a href="<?php echo base_url("admin/ekstra/tambah") ?>" class="btn btn-primary">Tambah</a>
</div>