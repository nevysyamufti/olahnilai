<h3>UBAH PENGATURAN</h3>
<form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label>Nama Pengaturan</label>
		<input type="text" name="nama_pengaturan" class="form-control" value="<?php echo $detail['nama_pengaturan'] ?>">
	</div>

	<div class="form-group">
		<label>Isi Pengaturan</label>
		<input type="text" name="isi_pengaturan" class="form-control" value="<?php echo $detail['isi_pengaturan'] ?>">
	</div>

	<div class="form-group">
		<label>Foto Pengaturan</label>
		<input type="file" name="foto_pengaturan" class="form-control" value="<?php echo $detail['foto_pengaturan'] ?>">
	</div>

	<div class="form-group">
		<button class="btn btn-primary">Simpan</button>
	</div>
</form>