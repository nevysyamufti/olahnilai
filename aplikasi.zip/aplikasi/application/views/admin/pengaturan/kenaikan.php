<h3>UBAH PERIODE KENAIKAN KELAS</h3>
<hr>
<form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label>Tanggal Mulai Periode Kenaikan Kelas</label>
		<input type="date" name="mulai" class="form-control" value="<?php echo $mulai ?>">
	</div>

	<div class="form-group">
		<label>Tanggal Selesai Periode Kenaikan Kelas</label>
		<input type="date" name="selesai" class="form-control" value="<?php echo $selesai ?>">
	</div>

	<div class="form-group">
		<button class="btn btn-primary">Simpan</button>
	</div>
</form>