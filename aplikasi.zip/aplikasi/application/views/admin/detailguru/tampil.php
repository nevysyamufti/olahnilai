<h3>DATA GURU MENGAJAR</h3>
<hr>
<table class="table table-bordered" id="thetable">
	<thead>
		<tr>
			<td>NO</td>
			<td>Tahun Ajaran</td>
			<td>Nama Guru</td>
			<td>Nama Mapel</td>
			<td>Nama Kelas</td>
			<td>Tingkat Kelas</td>
			<td>Aksi</td>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($detailguru as $key => $value): ?>
			<tr>
				<td><?php echo $key+1 ?></td>
				<td><?php echo $value['tahun_ajaran'] ?></td>
				<td><?php echo $value['nama_guru'] ?></td>
				<td><?php echo $value['nama_mapel'] ?></td>
				<td><?php echo $value['nama_kelas'] ?></td>
				<td><?php echo $value['tingkat_kelas'] ?></td>
				<td>
					<a href="<?php echo base_url("admin/detailguru/ubah/".$value['id_det_guru_mapel']) ?>" class="btn btn-primary">Ubah</a>
					<a href="<?php echo base_url("admin/detailguru/hapus/".$value["id_det_guru_mapel"]) ?>" class="btn btn-danger" onclick="return confirm('apakah yakin dihapus ?')">Hapus</a>
				</td>
			</tr>
		<?php endforeach ?>
	</tbody>
</table>
<a href="<?php echo base_url("admin/detailguru/tambah") ?>"class="btn btn-primary">Tambah</a>