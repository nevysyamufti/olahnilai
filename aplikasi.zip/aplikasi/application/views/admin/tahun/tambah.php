<h3>TAMBAH DATA TAHUN AJARAN</h3>
<form method="post">
	<div class="form-group">
		<label>Tahun Ajaran</label>
		<input type="" name="tahun_ajaran" class="form-control">
	</div>

	<div class="form-group">
		<label>Status Tahun Ajaran</label>
		<select name="status_tahun_ajaran" class="form-control">
			<option value="">Pilih Status</option>
			<option value="Aktif">Aktif</option>
			<option value="Tidak Aktif">Tidak Aktif</option>
		</select>
	</div>

	<div class="form-group">
		<button class="btn btn-primary"> Simpan </button>
	</div>
</form>