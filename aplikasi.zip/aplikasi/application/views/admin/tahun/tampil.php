<h3>DATA TAHUN AJARAN</h3>
<table class="table table-bordered">
	<thead>
		<tr>
			<td>No</td>
			<td>Tahun Ajaran</td>
			<td>Status Tahun Ajaran</td>
			<td>Aksi</td>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($tahun as $key => $value): ?>
			<tr>
				<td><?php echo $key+1 ?></td>
				<td><?php echo $value['tahun_ajaran'] ?></td>
				<td><?php echo $value['status_tahun_ajaran'] ?></td>
				<td>
					<a href="<?php echo base_url("admin/tahun/ubah/".$value['id_tahun_ajaran']) ?>" class="btn btn-primary">Ubah</a>
					<a href="<?php echo base_url("admin/tahun/hapus/".$value['id_tahun_ajaran']) ?>" class="btn btn-danger">Hapus</a>
				</td>
			</tr>
		<?php endforeach ?>
	</tbody>
</table>
<div>
	<a href="<?php echo base_url("admin/tahun/tambah")?>" class="btn btn-primary">Tambah</a>
</div>