<h3>UBAH DATA WALI KELAS</h3>
<?php echo $this->session->flashdata('gagal'); ?>
<form method="post">
	<div class="form-group">
		<label>Nama Wali Kelas</label>
		<select name="id_guru" class="form-control">
			
			<?php foreach ($guru as $key => $value): ?> 
				<option value="<?php echo $value['id_guru'] ?>" <?php echo set_select('id_guru', $value['id_guru'], (!empty($detail)AND $detail['id_guru']==$value['id_guru'] ? TRUE : FALSE)) ?>><?php echo $value['nip_guru']."-".$value['nama_guru'] ?></option>
			<?php endforeach ?>

		</select>
		<p><small><i class="text-danger"><?php echo form_error('id_guru') ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Kelas</label>
		<select name="id_kelas" class="form-control">
			<option value="">--Pilih--</option>
			<?php foreach ($kelas as $key => $value): ?> 
				<option value="<?php echo $value['id_kelas'] ?>" <?php echo set_select('id_kelas', $value['id_kelas'], (!empty($detail)AND $detail['id_kelas']==$value['id_kelas'] ? TRUE : FALSE)) ?>><?php echo $value['nama_kelas']."-".$value['tingkat_kelas'] ?></option>
			<?php endforeach ?>
		</select>
		<p><small><i class="text-danger"><?php echo form_error('id_kelas') ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Tahun Ajaran</label>
		<select name="id_tahun_ajaran" class="form-control">
			<option value="">--Pilih--</option>
			<?php foreach ($tahun as $key => $value): ?> 
				<option value="<?php echo $value['id_tahun_ajaran'] ?>" <?php echo set_select('id_tahun_ajaran', $value['id_tahun_ajaran'], (!empty($detail)AND $detail['id_tahun_ajaran']==$value['id_tahun_ajaran'] ? TRUE : FALSE)) ?>><?php echo $value['tahun_ajaran'] ?></option>
			<?php endforeach ?>
		</select>
		<p><small><i class="text-danger"><?php echo form_error('id_tahun_ajaran') ?></i></small></p>
	</div>

	<div class="form-group">
		<button class="btn btn-primary">Simpan</button>
		<a href="<?php echo base_url("admin/walikelas") ?>" class="btn btn-warning">Kembali</a>
	</div>

</form>