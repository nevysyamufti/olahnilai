<h3>DATA WALI KELAS</h3>
<br>
<table class="table table-bordered" id="thetable">
	<thead>
		<tr>
			<td>No</td>
			<td>Nama Wali Kelas</td>
			<td>NIP</td>
			<!--<td>Mengajar</td>-->
			<td>Kelas</td>
			<td>Tingkat Kelas</td>
			<td>Tahun Ajaran</td>
			<td>Aksi</td>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($walikelas as $key => $value): ?>
			<tr>
				<td><?php echo $key+1 ?></td>
				<td><?php echo $value['nama_guru'] ?></td>
				<td><?php echo $value['nip_guru'] ?></td>
				<td><?php echo $value['nama_kelas'] ?></td>
				<td><?php echo $value['tingkat_kelas'] ?></td>
				<td><?php echo $value['tahun_ajaran'] ?></td>
				<td>
					<a href="<?php echo base_url("admin/walikelas/ubah/".$value['id_wali_kelas']) ?>"class="btn btn-warning">Ubah</a>
					<a href="<?php echo base_url("admin/walikelas/hapus/".$value['id_wali_kelas']) ?>" class="btn btn-danger" onclick="return confirm('apakah yakin dihapus ?')">Hapus</a>
				</td>
			</tr>
		<?php endforeach ?>
	</tbody>
</table>
<a href="<?php echo base_url("admin/walikelas/tambah") ?>" class="btn btn-primary">Tambah</a>