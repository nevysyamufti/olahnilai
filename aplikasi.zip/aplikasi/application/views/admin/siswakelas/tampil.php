<h3>DATA SISWA KELAS</h3>
<hr>
<form class="form-inline" style="margin-bottom: 25px;">
	<div class="form-group">
		<select name="id_tahun_ajaran" class="form-control">
			<option value="">Pilih Tahun Ajaran</option>
			<?php foreach ($tahun_ajaran as $key => $value): ?>
				<option value="<?php echo $value['id_tahun_ajaran'] ?>" <?php if($value['id_tahun_ajaran']==$idt){echo "selected";} ?>><?php echo $value['tahun_ajaran'] ?></option>
			<?php endforeach ?>
		</select>
	</div>
	<div class="form-group">
		<select name="id_kelas" class="form-control">
			<option value="">Pilih Kelas</option>
			<?php foreach ($kelas as $key => $value): ?>
				<option value="<?php echo $value['id_kelas'] ?>" <?php if($value['id_kelas']==$idk){echo "selected";} ?>><?php echo $value['nama_kelas']." ".$value['tingkat_kelas'] ?></option>
			<?php endforeach ?>
		</select>
	</div>
	<div class="form-group">
		<button class="btn btn-primary">Filter</button>
	</div>
</form>

<form method="post">
<table class="table table-bordered" id="thetable">
	<thead>
		<tr>
			<td>No</td>
			<td>NIS</td>
			<td>Nama Siswa Kelas</td>
			<td>Wali Kelas</td>
			<?php if ($semester_aktif['id_semester']==13 AND $periode_kenaikan=="ya"): ?>
				<td>Kenaikan Kelas</td>
			<?php endif ?>
			<td>Aksi</td>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($siswakelas as $key => $value): ?>
			<tr>
				<td><?php echo $key+1 ?></td>
				<td><?php echo $value['nis_siswa'] ?></td>
				<td><?php echo $value['nama_siswa'] ?></td>
				<td><?php echo $value['nama_guru'] ?></td>
				<?php if ($semester_aktif['id_semester']==13 AND $periode_kenaikan=="ya"): ?>
					<td>
						<?php if ($tahun_kelas < 12): ?>
							<div class="radio">
								<label>
									<input type="radio" name="kenaikan[<?php echo $value['id_siswa'] ?>]" value="naik" checked='checked'<?php if($cek_kenaikan[$value['id_siswa']]=='naik'){echo "checked";} ?> onclick="return confirm('Apakah Anda Yakin ?')"> Naik Kelas
									<br>
									<input type="radio" name="kenaikan[<?php echo $value['id_siswa'] ?>]" value="tidak_naik" <?php if($cek_kenaikan[$value['id_siswa']]=='tidak_naik'){echo "checked";} ?> onclick="return confirm('Apakah Anda Yakin ?')"> Tidak Naik Kelas
								</label>
							</div>
						<?php else: ?>
							<div class="radio">
								<label>
									<input type="radio" name="kenaikan[<?php echo $value['id_siswa'] ?>]" value="lulus" <?php if($cek_kenaikan[$value['id_siswa']]=='lulus'){echo "checked";} ?> onclick="return confirm('Apakah Anda Yakin ?')"> Luluskan
									<br>
									<input type="radio" name="kenaikan[<?php echo $value['id_siswa'] ?>]" value="tidak_lulus" <?php if($cek_kenaikan[$value['id_siswa']]=='tidak_lulus'){echo "checked";} ?> onclick="return confirm('Apakah Anda Yakin ?')"> Tidak Lulus
								</label>
							</div>
						<?php endif ?>
					</td>
				<?php endif ?>
				<td>
					<a href="<?php echo base_url("admin/siswakelas/ubah/".$value['id_siswa_kelas']) ?>"class="btn btn-warning btn-block">Ubah</a>
					<a href="<?php echo base_url("admin/siswakelas/hapus/".$value['id_siswa_kelas']) ?>" class="btn btn-danger btn-block" onclick="return confirm('apakah yakin dihapus ?')">Hapus</a>
				</td>
			</tr>
		<?php endforeach ?>
	</tbody>
</table>
<a href="<?php echo base_url("admin/siswakelas/tambah") ?>" class="btn btn-primary">Tambah</a>

<?php if ($semester_aktif['id_semester']==13 AND $periode_kenaikan=="ya"): ?>
	<?php if ($id_kelas_selanjutnya=="Kosong"): ?>
		<button class="btn btn-primary" disabled="" class="disabled"><?php echo $kelas_selanjutnya ?></button>
	<?php else: ?>
		<button class="btn btn-primary" onclick="return confirm('Apakah Anda Yakin data sudah benar ? Jika belu silahkan di cek ulang')"><?php echo $kelas_selanjutnya ?></button>
	<?php endif ?>
<?php endif ?>
</form>