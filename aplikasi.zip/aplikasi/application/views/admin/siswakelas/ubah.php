<h3>Ubah Data Siswa Kelas</h3>
<?php echo $this->session->flashdata('gagal'); ?>
<form method="post">
	<div class="form-group">
		<label>NIS</label>
		<select name="id_siswa" class="form-control">
			<?php foreach ($siswa as $key => $value): ?> 
				<option value="<?php echo $value['id_siswa'] ?>" <?php echo set_select('id_siswa', $value['id_siswa'], (!empty($detail)AND $detail['id_siswa']==$value['id_siswa'] ? TRUE : FALSE)) ?>><?php echo $value['nis_siswa']."-".$value['nama_siswa'] ?></option>
			<?php endforeach ?>
		</select>
		<p><small><i class="text-danger"><?php echo form_error('id_siswa') ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Tahun Ajaran</label>
		<select name="id_tahun_ajaran" class="form-control"> 
			<?php foreach ($tahun_ajaran as $key => $value): ?> 
				<option value="<?php echo $value['id_tahun_ajaran'] ?>" <?php echo set_select('id_tahun_ajaran', $value['id_tahun_ajaran'], (!empty($detail)AND $detail['id_tahun_ajaran']==$value['id_tahun_ajaran'] ? TRUE : FALSE)) ?>><?php echo $value['tahun_ajaran'] ?></option>
			<?php endforeach ?>
		</select>
		<p><small><i class="text-danger"><?php echo form_error('id_tahun_ajaran') ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Kelas</label>
		<select name="id_kelas" class="form-control"> 
			<?php foreach ($kelas as $key => $value): ?> 
				<option value="<?php echo $value['id_kelas'] ?>" <?php echo set_select('id_kelas', $value['id_kelas'], (!empty($detail)AND $detail['id_kelas']==$value['id_kelas'] ? TRUE : FALSE)) ?>><?php echo $value['nama_kelas']." - ".$value['tingkat_kelas'] ?></option>
			<?php endforeach ?>
		</select>
		<p><small><i class="text-danger"><?php echo form_error('id_kelas') ?></i></small></p>
	</div>

	<div class="form-group">
		<button class="btn btn-primary">SIMPAN</button>
		<a href="<?php echo base_url("admin/siswakelas") ?>" class="btn btn-warning">KEMBALI</a>
	</div>
</form>