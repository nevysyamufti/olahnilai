<h3>Login Akun</h3>
<form>
	<div class="form-group">
		<label>ID Akun</label>
		<input type="text" name="" class="form-control">
	</div>

	<div class="form-group">
		<label>Kata Sandi</label>
		<input type="text" name="" class="form-control">
	</div>

	<div class="form-group">
		<button class="btn btn-primary">Login</button>
	</div>
</form>