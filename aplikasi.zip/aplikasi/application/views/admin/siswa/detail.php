<h3>DETAIL DATA SISWA</h3>
<hr>
<table class="table table-bordered">	
	<tr>
		<th width="25%">Nomor Induk Siswa</th>
		<th width="1%">:</th>
		<td><?php echo $detail['nis_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Nama Siswa</th>
		<th>:</th>
		<td><?php echo $detail['nama_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Alamat Siswa</th>
		<th>:</th>
		<td><?php echo $detail['alamat_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Tempat Lahir Siswa</th>
		<th>:</th>
		<td><?php echo $detail['tempat_lahir_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Tanggal Lahir Siswa</th>
		<th>:</th>
		<td><?php echo $detail['tanggal_lahir_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Jenis Kelamin</th>
		<th>:</th>
		<td><?php echo $detail['jk_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Nomor Telpon</th>
		<th>:</th>
		<td><?php echo $detail['notelp_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Status Siswa</th>
		<th>:</th>
		<td><?php echo $detail['status_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Sekolah Asal</th>
		<th>:</th>
		<td><?php echo $detail['sekolah_asal'] ?></td>
	</tr>
	<tr>	
		<th>Agama</th>
		<th>:</th>
		<td><?php echo $detail['agama_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Foto Siswa</th>
		<th>:</th>
		<td>
			<img src="<?php echo base_url("assets/img/siswa/".$detail['foto_siswa']) ?>" width="100px">
		</td>
	</tr>
	<tr>	
		<th>Ayah Siswa</th>
		<th>:</th>
		<td><?php echo $detail['ayah_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Ibu Siswa</th>
		<th>:</th>
		<td><?php echo $detail['ibu_siswa'] ?></td>
	</tr>
	<tr>	
		<th>No Telp Ayah</th>
		<th>:</th>
		<td><?php echo $detail['notelp_ayah'] ?></td>
	</tr>
	<tr>	
		<th>No Telp Ibu</th>
		<th>:</th>
		<td><?php echo $detail['notelp_ibu'] ?></td>
	</tr>
	<tr>	
		<th>Pendidikan Ayah</th>
		<th>:</th>
		<td><?php echo $detail['pendidikan_ayah'] ?></td>
	</tr>
	<tr>	
		<th>Pendidikan Ibu</th>
		<th>:</th>
		<td><?php echo $detail['pendidikan_ibu'] ?></td>
	</tr>
	<tr>	
		<th>Kerja Ayah</th>
		<th>:</th>
		<td><?php echo $detail['kerja_ayah'] ?></td>
	</tr>
	<tr>	
		<th>Kerja Ibu</th>
		<th>:</th>
		<td><?php echo $detail['kerja_ibu'] ?></td>
	</tr>
	<tr>	
		<th>Username Siswa</th>
		<th>:</th>
		<td><?php echo $detail['username_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Password Siswa</th>
		<th>:</th>
		<td><?php echo $detail['password_siswa'] ?></td>
	</tr>

</table>
<a href="<?php echo base_url("admin/siswa") ?>" class="btn btn-warning">Kembali</a>