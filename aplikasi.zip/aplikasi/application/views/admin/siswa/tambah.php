<h3>TAMBAH DATA SISWA</h3>
<hr>
<form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label>Nomor Induk Siswa</label>
		<input type="" name="nis_siswa" class="form-control" value="<?php echo set_value('nis_siswa') ?>">
		<p><small><i class="text-danger"><?php echo form_error("nis_siswa") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Nama Siswa</label>
		<input type="" name="nama_siswa" class="form-control" value="<?php echo set_value('nama_siswa') ?>">
		<p><small><i class="text-danger"><?php echo form_error("nama_siswa") ?></i></small></p> 
	</div>	

	<div class="form-group">
		<label>Alamat Siswa</label>
		<input type="text" name="alamat_siswa" class="form-control" value="<?php echo set_value('alamat_siswa') ?>">
		<p><small><i class="text-danger"><?php echo form_error("alamat_siswa") ?></i></small></p>
	</div>

	<div class="form-group" >
		<label>Tempat Lahir Siswa</label>
		<input type="" name="tempat_lahir_siswa" class="form-control" value="<?php echo set_value('tempat_lahir_siswa') ?>">
		<p><small><i class="text-danger"><?php echo form_error("tempat_lahir_siswa") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Tanggal Lahir Siswa</label>
		<input type="date" name="tanggal_lahir_siswa" class="form-control" value="<?php echo set_value('tanggal_lahir_siswa') ?>">
		<p><small><i class="text-danger"><?php echo form_error("tanggal_lahir_siswa") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Jenis Kelamin Siswa</label>
		<select name="jk_siswa" class="form-control" value="<?php echo set_value('jk_siswa') ?>">
			<option value="">Pilih</option>
			<option value="Laki-laki">Laki</option>
			<option value="Perempuan">Perempuan</option>
		</select>
	</div>

	<div class="form-group">
		<label>Nomor Telp Siswa</label>
		<input type="" name="notelp_siswa" class="form-control" value="<?php echo set_value('notelp_siswa') ?>">
		<p><small><i class="text-danger"><?php echo form_error("notelp_siswa") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Status Siswa</label>
		<select name="status_siswa" class="form-control" value="<?php echo set_value('status_siswa') ?>">
			<option value="">Pilih</option>
			<option value="Aktif">Aktif</option>
			<option value="Tidak Aktif">Tidak Aktif</option>
		</select>
	</div>

	<div class="form-group">
		<label>Sekolah Asal</label>
		<input type="" name="sekolah_asal" class="form-control" value="<?php echo set_value('sekolah_asal') ?>">
		<p><small><i class="text-danger"><?php echo form_error("sekolah_asal") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Agama</label>
		<select name="agama_siswa" class="form-control" value="<?php echo set_value('agama_siswa') ?>">
			<option value="">Pilih</option>
			<option value="Islam">Islam</option>
			<option value="Hindu">Hindu</option>
			<option value="Buddha">Budha</option>
			<option value="Katolik">Katolik</option>
			<option value="Protestan">Protestan</option>
			<option value="Khonghucu">Khonghucu</option>
		</select>
	</div>

	<div class="form-group">
		<label>Foto Siswa</label>
		<input type="file" name="foto_siswa" class="form-control">
	</div>

	<div class="form-group">
		<label>Ayah Siswa</label>
		<input type="" name="ayah_siswa" class="form-control" value="<?php echo set_value('ayah_siswa') ?>">
		<p><small><i class="text-danger"><?php echo form_error("ayah_siswa") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Ibu Siswa</label>
		<input type="" name="ibu_siswa" class="form-control" value="<?php echo set_value('ibu_siswa') ?>">
		<p><small><i class="text-danger"><?php echo form_error("ibu_siswa") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Kerja Ayah</label>
		<input type="" name="kerja_ayah" class="form-control" value="<?php echo set_value('kerja_ayah') ?>">
		<p><small><i class="text-danger"><?php echo form_error("kerja_ayah") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Kerja Ibu</label>
		<input type="" name="kerja_ibu" class="form-control" value="<?php echo set_value('kerja_ibu') ?>">
		<p><small><i class="text-danger"><?php echo form_error("kerja_ibu") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Nomor Telp Ayah</label>
		<input type="" name="notelp_ayah" class="form-control" value="<?php echo set_value('notelp_ayah') ?>">
		<p><small><i class="text-danger"><?php echo form_error("notelp_ayah") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Nomor Telp Ibu</label>
		<input type="" name="notelp_ibu" class="form-control" value="<?php echo set_value('notelp_ibu') ?>">
		<p><small><i class="text-danger"><?php echo form_error("notelp_ibu") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Pendidikan Ayah</label>
		<input type="" name="pendidikan_ayah" class="form-control" value="<?php echo set_value('pendidikan_ayah') ?>">
		<p><small><i class="text-danger"><?php echo form_error("pendidikan_ayah") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Pendidikan Ibu</label>
		<input type="" name="pendidikan_ibu" class="form-control" value="<?php echo set_value('pendidikan_ibu') ?>">
		<p><small><i class="text-danger"><?php echo form_error("pendidikan_ibu") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Username Siswa</label>
		<input type="" name="username_siswa" class="form-control" value="<?php echo set_value('username_siswa') ?>">
		<p><small><i class="text-danger"><?php echo form_error("username_siswa") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Password Siswa</label>
		<input type="password" name="password_siswa" class="form-control" value="<?php echo set_value('password_siswa') ?>">
		<p><small><i class="text-danger"><?php echo form_error("password_siswa") ?></i></small></p>
	</div>

	<div>
		<button class="btn btn-primary">Simpan</button>
		<a href="<?php echo base_url("admin/siswa") ?>" class="btn btn-warning">Kembali</a>
	</div>
</form>