<h3>UBAH DATA</h3>
<hr>
<form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label>Nomor Induk Siswa</label>
		<input type="" name="nis_siswa" class="form-control" value="<?php echo $detail['nis_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Nama Siswa</label>
		<input type="" name="nama_siswa" class="form-control" value="<?php echo $detail['nama_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Alamat Siswa</label>
		<input type="text" name="alamat_siswa" class="form-control" value="<?php echo $detail['alamat_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Tempat Lahir Siswa</label>
		<input type="" name="tempat_lahir_siswa" class="form-control" value="<?php echo $detail['tempat_lahir_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Tanggal Lahir Siswa</label>
		<input type="date" name="tanggal_lahir_siswa" class="form-control" value="<?php echo $detail['tanggal_lahir_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Jenis Kelamin Siswa</label>
		<select name="jk_siswa" class="form-control" value="<?php echo $detail['jk_siswa'] ?>">
			<option value="">Pilih</option>
			<option value="Laki-laki" <?php if ($detail['jk_siswa']=='Laki-laki') {echo "selected" ;
			} ?>>Laki</option>
			<option value="Perempuan" <?php if ($detail['jk_siswa']=='Perempuan') {echo "selected" ;
			} ?>>Perempuan</option>
		</select>
	</div>

	<div class="form-group">
		<label>Nomor Telp Siswa</label>
		<input type="" name="notelp_siswa" class="form-control" value="<?php echo $detail['notelp_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Status Siswa</label>
		<select name="status_siswa" class="form-control" value="<?php echo $detail['status_siswa'] ?>">
			<option value="">Pilih</option>
			<option value="Aktif" <?php if ($detail['status_siswa']=='Aktif') {echo "selected" ;
			} ?>>Aktif</option>
			<option value="Tidak Aktif" <?php if ($detail['status_siswa']=='Tidak Aktif') {echo "selected" ;
			} ?>>Tidak Aktif</option>
		</select>
	</div>

	<div class="form-group">
		<label>Asal Sekolah Siswa</label>
		<input type="" name="sekolah_asal" class="form-control" value="<?php echo $detail['sekolah_asal'] ?>">
	</div>


	<div class="form-group">
		<label>Agama</label>
		<select name="agama_siswa" class="form-control" value="<?php echo $detail['agama_siswa'] ?>">
			<option value="">Pilih</option>
			<option value="Islam" <?php if($detail['agama_siswa']=='Islam'){echo "selected";} ?>>Islam</option>
			<option value="Hindu" <?php if($detail['agama_siswa']=='Hindu'){echo "selected";} ?>>Hindu</option>
			<option value="Buddha" <?php if($detail['agama_siswa']=='Buddha'){echo "selected";} ?>>Budha</option>
			<option value="Katolik" <?php if($detail['agama_siswa']=='Katolik'){echo "selected";} ?>>Katolik</option>
			<option value="Protestan" <?php if($detail['agama_siswa']=='Protestan'){echo "selected";} ?>>Protestan</option>
			<option value="Khonghucu" <?php if($detail['agama_siswa']=='Khonghucu'){echo "selected";} ?>>Khonghucu</option>
		</select>
	</div>

	<div class="form-group">
		<label>Foto Siswa</label>
		<br>	
		<img src="<?php echo base_url("./assets/img/siswa/".$detail['foto_siswa']) ?>" width="200px">
		<input type="file" name="foto_siswa" class="form-control" value="<?php echo $detail['foto_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Ayah Siswa</label>
		<input type="" name="ayah_siswa" class="form-control" value="<?php echo $detail['ayah_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Ibu Siswa</label>
		<input type="" name="ibu_siswa" class="form-control" value="<?php echo $detail['ibu_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>No Telp Ayah</label>
		<input type="" name="notelp_ayah" class="form-control" value="<?php echo $detail['notelp_ayah'] ?>">
	</div>

	<div class="form-group">
		<label>No Telp Ibu</label>
		<input type="" name="notelp_ibu" class="form-control" value="<?php echo $detail['notelp_ibu'] ?>">
	</div>

	<div class="form-group">
		<label>Pendidikan Ayah</label>
		<input type="" name="pendidikan_ayah" class="form-control" value="<?php echo $detail['pendidikan_ayah'] ?>">
	</div>

	<div class="form-group">
		<label>Pendidikan Ibu</label>
		<input type="" name="pendidikan_ibu" class="form-control" value="<?php echo $detail['pendidikan_ibu'] ?>">
	</div>

	<div class="form-group">
		<label>Kerja Ayah</label>
		<input type="" name="kerja_ayah" class="form-control" value="<?php echo $detail['kerja_ayah'] ?>">
	</div>

	<div class="form-group">
		<label>Kerja Ibu</label>
		<input type="" name="kerja_ibu" class="form-control" value="<?php echo $detail['kerja_ibu'] ?>">
	</div>

	<div class="form-group">
		<label>Username Siswa</label>
		<input type="" name="username_siswa" class="form-control" value="<?php echo $detail['username_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Password Siswa</label>
		<input type="password" name="password_siswa" class="form-control">
		<p><small><i class="text-danger">****Kosongkan jika tidak ingin mengubah</i></small></p>
	</div>

	<div>
		<button class="btn btn-primary">Simpan</button>
		<a href="<?php echo base_url("admin/siswa") ?>" class="btn btn-warning">Kembali</a>
	</div>
</form>