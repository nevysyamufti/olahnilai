<h3>DATA MATA PELAJARAN</h3>
<br>
<table class="table table-bordered" id="thetable">
	<thead>
		<tr>
			<th>No</th>
			<th>Nama Jurusan</th>
			<th>Nama Mata Pelajaran</th>
			<th>KKM</th>
			<th>Kelompok</th>
			<th>Urutan</th>
			<th>Aksi</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($mapel as $key => $value): ?>
			<tr>
				<td><?php echo $key+1 ?></td>
				<td><?php echo $value['nama_jurusan'] ?></td>
				<td><?php echo $value['nama_mapel'] ?></td>
				<td><?php echo $value['kkm_mapel'] ?></td>
				<td><?php echo $value['kelompok_mapel'] ?></td>
				<td><?php echo $value['urutan_mapel'] ?></td>
				<td>
					<a href="<?php echo base_url("admin/mapel/ubah/".$value['id_mapel']) ?>" class="btn btn-primary">Ubah</a>
					<a href="<?php echo base_url("admin/mapel/hapus/".$value['id_mapel']) ?>" class="btn btn-danger" onclick="return confirm('Apakah yakin dihapus ?')">Hapus</a>
				</td>
			</tr>
		<?php endforeach ?>
	</tbody>
</table>
<a href="<?php echo base_url("admin/mapel/tambah") ?>" class="btn btn-primary">Tambah</a>