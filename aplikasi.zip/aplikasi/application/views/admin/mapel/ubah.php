<h3>UBAH DATA MATA PELAJARAN</h3>
<?php echo $this->session->flashdata('gagal'); ?>
<form method="post">
	<div class="form-group">
		<label>Nama Jurusan</label>
		<select name="id_jurusan" class="form-control">
			<?php foreach ($jurusan as $key => $value): ?> 
				<option value="<?php echo $value['id_jurusan'] ?>" <?php echo set_select('id_jurusan', $value['id_jurusan'], (!empty($detail)AND $detail['id_jurusan']==$value['id_jurusan'] ? TRUE : FALSE)) ?>><?php echo $value['nama_jurusan'] ?></option>
			<?php endforeach ?>
		</select>
		<p><small><i class="text-danger"><?php echo form_error('id_jurusan')?></i></small></p>
	</div>

	<div class="form-group">
		<label>Nama Mata Pelajaran</label>
		<input type="text" name="nama_mapel" class="form-control" value="<?php echo set_value('nama_mapel', $detail['nama_mapel']) ?>">
		<p><small><i class="text-danger"><?php echo form_error('nama_mapel')?></i></small></p>
	</div>

	<div class="form-group">
		<label>KKM</label>
		<input type="" name="kkm_mapel" class="form-control" value="<?php echo set_value('kkm_mapel', $detail['kkm_mapel']) ?>">
	</div>

	<div class="form-group">
		<label>Kelompok Mapel</label>
		<select name="kelompok_mapel" class="form-control">
			<option value="">--Pilih--</option>			
			<option value="A" <?php echo set_select('kelompok_mapel', $detail['kelompok_mapel'], (!empty($detail)AND $detail['kelompok_mapel']=='A' ? TRUE : FALSE)) ?>>Kelompok (A) Umum</option>
			<option value="B" <?php echo set_select('kelompok_mapel', $detail['kelompok_mapel'], (!empty($detail)AND $detail['kelompok_mapel']=='B' ? TRUE : FALSE)) ?>>Kelompok (B) Umum</option>
			<option value="C" <?php echo set_select('kelompok_mapel', $detail['kelompok_mapel'], (!empty($detail)AND $detail['kelompok_mapel']=='C' ? TRUE : FALSE)) ?>>Kelompok (C) Peminatan</option>
		</select>
		<p><small><i class="text-danger"><?php echo form_error("kelompok_mapel") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Urutan Mapel</label>
		<input type="number" name="urutan_mapel" class="form-control" value="<?php echo set_value("urutan_mapel", $detail['urutan_mapel']) ?>">
	</div>

	<div class="form-group">
		<button class="btn btn-primary">Simpan</button>
		<a href="<?php echo base_url("admin/mapel") ?>" class="btn btn-warning">Kembali</a>
	</div>
</form>