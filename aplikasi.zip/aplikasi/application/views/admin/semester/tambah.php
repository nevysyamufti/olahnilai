<h3>TAMBAH DATA SEMESTER</h3>
<form method="post">
	<div class="form-group">
		<label>Nama Semester</label>
		<input type="" name="nama_semester" class="form-control" value="<?php echo set_value('nama_semester') ?>">
		<p><small><i class="text-danger"><?php echo form_error("nama_semester") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Status Semester</label>
		<select name="status_semester" class="form-control">
			<option value="">Pilih</option>
			<option value="Aktif">Aktif</option>
			<option value="Tidak Aktif">Tidak aktif</option>
		</select>
	</div>

	<div class="form-group">
		<button class="btn btn-primary">Simpan</button>
		<a href="<?php echo base_url("admin/semester") ?>" class="btn btn-warning">Kembali</a>
	</div>
</form>
