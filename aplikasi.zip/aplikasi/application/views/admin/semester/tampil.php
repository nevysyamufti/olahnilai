<h3>DATA SEMESTER</h3>
<br>
<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama Semester</th>
				<th>Status Semester</th>
				<th>Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($semester as $key => $value): ?>
				<tr>
					<td><?php echo $key+1 ?></td>
					<td><?php echo $value['nama_semester'] ?></td>
					<td><?php echo $value['status_semester'] ?></td>
					<td>
						<a href="<?php echo base_url("admin/semester/ubah/".$value['id_semester']) ?>" class="btn btn-warning">Ubah</a>
						<a href="<?php echo base_url("admin/semester/hapus/".$value['id_semester']) ?>" class="btn btn-danger">Hapus</a>
					</td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>
	<div>
		<a href="<?php echo base_url("admin/semester/tambah") ?>" class="btn btn-primary">Tambah</a>
	</div>
</div>