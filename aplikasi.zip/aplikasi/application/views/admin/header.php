

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>Admin Penilaian</title>

	<!-- Bootstrap -->
	<link href="<?php echo base_url("assets/css/bootstrap.min.css") ?>" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@600&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url("assets/font-awesome-4.7.0/css/font-awesome.css") ?>">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/css/inadmin.css") ?>">
</head>
<body>

	<div id="wrapper">
		<nav class="navbar navbar-default">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
				data-target=".sidebar-collapse" aria-expanded="false">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
			<a class="navbar-brand" href="#">Sistem Informasi Pengolahan Nilai</a>
			</div>
		</nav> 

		<nav class="navbar-default navbar-side">
			<div class="sidebar-collapse">
				<div class="user">
					<img src="<?php echo base_url("assets/img/femaleuser.png") ?>" alt="">
					<h3><?php echo nama_admin() ?></h3>
					<p>Seorang Administrator</p>
				</div>
				<ul class="nav" id="main-menu">
					<li> <a href="<?php echo base_url("admin") ?>"><i class="fa fa-dashboard"></i> Home</a> </li>
					<li class="tr-tree"> 
						<a href="#"><i class="fa fa-group"></i> Setting <i class="pull-right fa fa-angle-right"></i></a> 
						<ul class="tr-tree-menu">
							<li><a href="<?php echo base_url("admin/tahun") ?>">Tahun Ajaran</a></li>
							<li><a href="<?php echo base_url("admin/jurusan") ?>">Jurusan</a></li>
							<li><a href="<?php echo base_url("admin/semester") ?>">Semester</a></li>
							<li><a href="<?php echo base_url("admin/kelas") ?>">Kelas</a></li>
							<li><a href="<?php echo base_url("admin/pengaturan/kenaikan") ?>">Periode Kenaikan Kelas</a></li>
								<!-- <li><a href="">Pak Kebon</a></li>
								<li><a href="">Pak Kantin</a></li>
								<li><a href="">Pak Satpam</a></li> -->
						</ul>
					</li>
					<li class="tr-tree">
						<a href="#"><i class="fa fa-database"></i> Data Master <i class="pull-right fa fa-angle-right"></i></a>
						<ul class="tr-tree-menu">
							<li><a href="<?php echo base_url("admin/admin") ?>">Administrator</a></li>
							<li><a href="<?php echo base_url("admin/guru") ?>">Guru</a></li>
							<li><a href="<?php echo base_url("admin/siswa") ?>">Siswa</a></li>
							<li><a href="<?php echo base_url("admin/mapel") ?>">Mata Pelajaran</a></li>
							<li><a href="<?php echo base_url("admin/detailguru") ?>">Detail Guru Mapel</a></li>
							<li><a href="<?php echo base_url("admin/walikelas") ?>">Wali Kelas</a></li>
							<li><a href="<?php echo base_url("admin/siswakelas") ?>">Siswa Kelas</a></li>
							<li><a href="<?php echo base_url("admin/ekstra") ?>">Ekstrakurikuler</a></li>
							<li><a href="<?php echo base_url("admin/pengaturan") ?>">Pengaturan</a></li>
							<li><a href="<?php echo base_url("admin/kepsek") ?>">Kepala Sekolah</a></li>
						</ul>
					</li>
					<li> <a href=""><i class="fa fa-cogs"></i> Pengaturan</a> </li>
					<li> <a href="<?php echo base_url("admin/logout") ?>"><i class="fa fa-sign-out"></i> Logout</a> </li>
				</ul>
			</div>
		</nav>

		<div id="page-wrapper">
			<div id="page-inner">