<h3>DATA KEPALA SEKOLAH</h3>
<hr>
<div class="table-responsive">
	<table class="table table-bordered" id="thetable">
		<thead>
			<tr>
				<th>No</th>
				<th>Nomor Induk Pegawai</th>
				<th>Nama Kepala Sekolah</th>
				<!-- <th>Email</th> -->
				<th>Username</th>
				<th>Password</th>
				<th>Status</th>
				<th>Aksi</th>
			</tr> 
		</thead>
		<tbody>
			<?php foreach ($kepsek as $key => $value): ?>
				<tr>
					<td><?php echo $key+1 ?></td>
					<td><?php echo $value['nip_kepala_sekolah'] ?></td>
					<td><?php echo $value['nama_kepala_sekolah'] ?></td>
					<!-- <td><?php echo $value['email_kepala_sekolah'] ?></td> -->
					<td><?php echo $value['username_kepala_sekolah'] ?></td>
					<td><?php echo $value['password_kepala_sekolah'] ?></td>
					<td><?php echo $value['status_kepala_sekolah'] ?></td>
					<td>
						<a href="<?php echo base_url("admin/kepsek/ubah/".$value['id_kepala_sekolah']) ?>"class="btn btn-warning">Ubah</a>

						<a href="<?php echo base_url("admin/kepsek/hapus/".$value['id_kepala_sekolah']) ?>"class="btn btn-danger">Hapus</a>
					</td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>
	<a href="<?php echo base_url('admin/kepsek/tambah') ?>" class="btn btn-primary">Tambah</a>
</div>