<h3>Tambah Data Kepala Sekolah</h3>
<hr>
<form method="post">
	<div class="form-group">
		<label>Nomor Induk Pegawai</label>
		<input type="" name="nip_kepala_sekolah" class="form-control" value="<?php echo set_value('nip_kepala_sekolah') ?>">
		<p><small><i class="text-danger"><?php echo form_error("nip_kepala_sekolah") ?></i></small></p>
	</div>
	<div class="form-group">
		<label>Nama Kepala Sekolah</label>
		<input type="text" name="nama_kepala_sekolah" class="form-control" value="<?php echo set_value('nama_kepala_sekolah') ?>">
		<p><small><i class="text-danger"><?php echo form_error("nama_kepala_sekolah") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Email</label>
		<input type="email" name="email_kepala_sekolah" class="form-control" value="<?php echo set_value('email_kepala_sekolah') ?>">
		<p><small><i class="text-danger"><?php echo form_error("email_kepala_sekolah") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Username</label>
		<input type="text" name="username_kepala_sekolah" class="form-control" value="<?php echo set_value('username_kepala_sekolah') ?>">
		<p><small><i class="text-danger"><?php echo form_error("username_kepala_sekolah") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Password</label>
		<input type="password" name="password_kepala_sekolah" class="form-control" value="<?php echo set_value('password_kepala_sekolah') ?>">
		<p><small><i class="text-danger"><?php echo form_error("password_kepala_sekolah") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Status Kepala Sekolah</label>
		<select name="status_kepala_sekolah" class="form-control">
			<option value="">Pilih</option>
			<option value="Aktif">Aktif</option>
			<option value="Tidak Aktif">Tidak aktif</option>
		</select>
	</div>

	<div>
		<button class="btn btn-primary">SIMPAN</button>
		<a href="<?php echo base_url("admin/kepsek") ?>" class="btn btn-warning">Kembali</a>
	</div>
</form>