<h3>UBAH DATA KEPALA SEKOLAH</h3>
<hr>
<form method="post">
	<div class="form-group">
		<label>Nomor Induk Pegawai</label>
		<input type="" name="nip_kepala_sekolah" class="form-control" value="<?php echo $detail['nip_kepala_sekolah'] ?>">
	</div>
	<div class="form-group">
		<label>Nama Kepala Sekolah</label>
		<input type="" name="nama_kepala_sekolah" class="form-control" value="<?php echo set_value("nama_kepala_sekolah", $detail['nama_kepala_sekolah']) ?>">
		<p><small><i class="text-danger"><?php echo form_error("nama_kepala_sekolah") ?></i></small></p>
	</div>

<div class="form-group">
		<label>Email</label>
		<input type="" name="email_kepala_sekolah" class="form-control" value="<?php echo set_value("email_kepala_sekolah", $detail['email_kepala_sekolah']) ?>">
		<p><small><i class="text-danger"><?php echo form_error("email_kepala_sekolah") ?></i></small></p>
	</div>	
 
	<div class="form-group">
		<label>Username</label>
		<input type="" name="username_kepala_sekolah" class="form-control" value="<?php echo set_value("username_kepala_sekolah", $detail['username_kepala_sekolah']) ?>">
		<p><small><i class="text-danger"><?php echo form_error("username_kepala_sekolah") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Password</label>
		<input type="password" name="password_kepala_sekolah" class="form-control">
		<p><small><i class="text-danger">****Kosongkan jika tidak ingin diubah	</i></small></p>
	</div>

	<div class="form-group">
		<label>Status Kepala Sekolah</label>
		<select name="status_kepala_sekolah" class="form-group" value="<?php echo set_value("status_kepala_sekolah", $detail['status_kepala_sekolah']) ?>">
			<option value="Aktif" <?php if($detail['status_kepala_sekolah']=="Aktif"){echo"selected";} ?>>Aktif</option>
			<option value="Tidak Aktif" <?php if($detail['status_kepala_sekolah']=="Tidak Aktif"){echo"selected";} ?>>Tidak Aktif</option>
		</select>
	</div>

	<div class="form-group">
		<button class="btn btn-primary">Simpan</button>
		<a href="<?php echo base_url("admin/kepsek") ?>" class="btn btn-warning">Kembali</a>
	</div>
</form>