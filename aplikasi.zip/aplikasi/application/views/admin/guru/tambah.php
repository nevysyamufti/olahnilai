<h3>TAMBAH DATA GURU</h3> 
<hr>
<form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label>Nomor Induk Pegawai</label>
		<input type="text" name="nip_guru" class="form-control" value="<?php echo set_value('nip_guru') ?>">
		<p><small><i class="text-danger"><?php echo form_error("nip_guru") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Nama Guru</label>
		<input type="text" name="nama_guru" class="form-control" value="<?php echo set_value('nama_guru') ?>">
		<p><small><i class="text-danger"><?php echo form_error("nama_guru") ?></i></small></p>
	</div>	

	<div class="form-group">
		<label>Alamat Guru</label>
		<input type="text" name="alamat_guru" class="form-control" value="<?php echo set_value('alamat_guru') ?>">
		<p><small><i class="text-danger"><?php echo form_error("alamat_guru") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Tempat Lahir Guru</label>
		<input type="text" name="tempat_lahir_guru" class="form-control" value="<?php echo set_value('tanggal_lahir_guru') ?>">
		<p><small><i class="text-danger"><?php echo form_error("tempat_lahir_guru") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Tanggal Lahir Guru</label>
		<input type="date" name="tanggal_lahir_guru" class="form-control" value="<?php echo set_value('tanggal_lahir_guru') ?>">
		<p><small><i class="text-danger"><?php echo form_error("tanggal_lahir_guru") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Jenis Kelamin Guru</label>
		<select name="jk_guru" class="form-control">
			<option value="">Pilih</option>
			<option value="Laki-laki">Laki</option>
			<option value="Perempuan">Perempuan</option>
		</select>
	</div>

	<div class="form-group">
		<label>Agama</label>
		<select name="agama_guru" class="form-control">
			<option value="">Pilih</option>
			<option value="Islam">Islam</option>
			<option value="Hindu">Hindu</option>
			<option value="Buddha">Budha</option>
			<option value="Katolik">Katolik</option>
			<option value="Protestan">Protestan</option>
			<option value="Khonghucu">Khonghucu</option>
		</select>
	</div>

	<div class="form-group">
		<label>Pendidikan Guru</label>
		<input type="text" name="pendidikan_guru" class="form-control" value="<?php echo set_value('pendidikan_guru') ?>">
		<p><small><i class="text-danger"><?php echo form_error("pendidikan_guru") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Nomor Telp Guru</label>
		<input type="text" name="notelp_guru" class="form-control" value="<?php echo set_value('notelp_guru') ?>">
		<p><small><i class="text-danger"><?php echo form_error("notelp_guru") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Foto Guru</label>
		<input type="file" name="foto_guru" class="form-control">
	</div>

	<div class="form-group">
		<label>Username Guru</label>
		<input type="text" name="username_guru" class="form-control" value="<?php echo set_value('username_guru') ?>">
		<p><small><i class="text-danger"><?php echo form_error("username_guru") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Password Guru</label>
		<input type="password" name="password_guru" class="form-control" value="<?php echo set_value('password_guru') ?>">
		<p><small><i class="text-danger"><?php echo form_error("password_guru") ?></i></small></p>
	</div>

	<div>
		<button class="btn btn-primary">Simpan</button>
		<a href="<?php echo base_url("admin/guru") ?>" class="btn btn-warning">Kembali</a>
	</div>
</form>