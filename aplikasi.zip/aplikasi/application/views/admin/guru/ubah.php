<h3>UBAH DATA GURU</h3>
<hr>
<form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label>Nomor Induk Pegawai</label>
		<input type="" name="nip_guru" class="form-control" value="<?php echo $detail['nip_guru'] ?>">
	</div>

	<div class="form-group">
		<label>Nama Guru</label>
		<input type="" name="nama_guru" class="form-control" value="<?php echo $detail['nama_guru'] ?>">
		<p><small><i class="text-danger"><?php echo form_error("nama_guru") ?></i></small></p>
	</div>	

	<div class="form-group">
		<label>Alamat Guru</label>
		<input type="text" name="alamat_guru" class="form-control" value="<?php echo $detail['alamat_guru'] ?>">
		<p><small><i class="text-danger"><?php echo form_error("alamat_guru") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Tempat Lahir Guru</label>
		<input type="" name="tempat_lahir_guru" class="form-control" value="<?php echo $detail['tempat_lahir_guru'] ?>">
		<p><small><i class="text-danger"><?php echo form_error("tempat_lahir_guru") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Tanggal Lahir Guru</label>
		<input type="date" name="tanggal_lahir_guru" class="form-control" value="<?php echo $detail['tanggal_lahir_guru'] ?>">
		<p><small><i class="text-danger"><?php echo form_error("tanggal_lahir_guru") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Jenis Kelamin Guru</label>
		<select name="jk_guru" class="form-control" value="<?php echo $detail['jk_guru'] ?>">
			<option value="">Pilih</option>
			<option value="Laki-laki" <?php if ($detail['jk_guru']=='Laki-laki') {echo "selected" ;
			} ?>>Laki</option>
			<option value="Perempuan" <?php if ($detail['jk_guru']=='Perempuan') {echo "selected" ;
			} ?>>Perempuan</option>
		</select>
	</div>

	<div class="form-group">
		<label>Agama</label>
		<select name="agama_guru" class="form-control" value="<?php echo $detail['agama_guru'] ?>">
			<option value="">Pilih</option>
			<option value="Islam" <?php if($detail['agama_guru']=='Islam'){echo "selected";} ?>>Islam</option>
			<option value="Hindu" <?php if($detail['agama_guru']=='Hindu'){echo "selected";} ?>>Hindu</option>
			<option value="Buddha" <?php if($detail['agama_guru']=='Buddha'){echo "selected";} ?>>Budha</option>
			<option value="Katolik" <?php if($detail['agama_guru']=='Katolik'){echo "selected";} ?>>Katolik</option>
			<option value="Protestan" <?php if($detail['agama_guru']=='Protestan'){echo "selected";} ?>>Protestan</option>
			<option value="Khonghucu" <?php if($detail['agama_guru']=='Khonghucu'){echo "selected";} ?>>Khonghucu</option>
		</select>
	</div>

	<div class="form-group">
		<label>Pendidikan Guru</label>
		<input type="" name="pendidikan_guru" class="form-control" value="<?php echo $detail['pendidikan_guru'] ?>">
		<p><small><i class="text-danger"><?php echo form_error("pendidikan_guru") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Nomor Telp Guru</label>
		<input type="" name="notelp_guru" class="form-control" value="<?php echo $detail['notelp_guru'] ?>">
		<p><small><i class="text-danger"><?php echo form_error("notelp_guru") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Foto Guru</label>
		<br>	
		<img src="<?php echo base_url("./assets/img/guru/".$detail['foto_guru']) ?>" width="150px">
		<input type="file" name="foto_guru" class="form-control" value="<?php echo $detail['foto_guru'] ?>">
	</div>

	<div class="form-group">
		<label>Username Guru</label>
		<input type="" name="username_guru" class="form-control" value="<?php echo $detail['username_guru'] ?>">
		<p><small><i class="text-danger"><?php echo form_error("username_guru") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Password Guru</label>
		<input type="password" name="password_guru" class="form-control">
		<p><small><i class="text-danger"><?php echo form_error("password_guru") ?></i></small></p>
		<p><small><i class="text-danger">****Kosongkan jika tidak ingin diubah	</i></small></p>
	</div>

	<div>
		<button class="btn btn-primary">Simpan</button>
		<a href="<?php echo base_url("admin/guru") ?>" class="btn btn-warning">Kembali</a>
	</div>
</form>