<h3>DETAIL DATA GURU</h3>
<hr>
<table class="table table-bordered">	
	<tr>
		<th width="25%">Nomor Induk Pegawai</th>
		<th width="1%">:</th>
		<td><?php echo $detail['nip_guru'] ?></td>
	</tr>
	<tr>	
		<th>Nama Guru</th>
		<th>:</th>
		<td><?php echo $detail['nama_guru'] ?></td>
	</tr>
	<tr>	
		<th>Alamat Guru</th>
		<th>:</th>
		<td><?php echo $detail['alamat_guru'] ?></td>
	</tr>
	<tr>	
		<th>Tempat Lahir Guru</th>
		<th>:</th>
		<td><?php echo $detail['tempat_lahir_guru'] ?></td>
	</tr>
	<tr>	
		<th>Tanggal Lahir Guru</th>
		<th>:</th>
		<td><?php echo $detail['tanggal_lahir_guru'] ?></td>
	</tr>
	<tr>	
		<th>Jenis Kelamin</th>
		<th>:</th>
		<td><?php echo $detail['jk_guru'] ?></td>
	</tr>
	<tr>	
		<th>Agama</th>
		<th>:</th>
		<td><?php echo $detail['agama_guru'] ?></td>
	</tr>
	<tr>	
		<th>Pendidikan Guru</th>
		<th>:</th>
		<td><?php echo $detail['pendidikan_guru'] ?></td>
	</tr>
	<tr>	
		<th>Nomor Telpon</th>
		<th>:</th>
		<td><?php echo $detail['notelp_guru'] ?></td>
	</tr>
	<tr>	
		<th>Foto Guru</th>
		<th>:</th>
		<td>
			<img src="<?php echo base_url("assets/img/guru/".$detail['foto_guru']) ?>" width="150px">
		</td>
	</tr>
	<tr>	
		<th>Username Guru</th>
		<th>:</th>
		<td><?php echo $detail['username_guru'] ?></td>
	</tr>
	<tr>	
		<th>Password Guru</th>
		<th>:</th>
		<td><?php echo $detail['password_guru'] ?></td>
	</tr>

</table>
<a href="<?php echo base_url("admin/guru") ?>" class="btn btn-warning">Kembali</a>