<h3>DATA KELAS</h3>
<table class="table table-bordered" id="thetable">
	<thead>
		<tr>
			<td>No</td>
			<td>Nama Jurusan</td>
			<td>Nama Kelas</td>
			<td>Tingkat Kelas</td>
			<td>Aksi</td>
		</tr>
	</thead>
	<tbody>
		<?php foreach ($kelas as $key => $value): ?>
			<tr>
				<td><?php echo $key+1 ?></td>
				<td><?php echo $value['nama_jurusan'] ?></td>
				<td><?php echo $value['nama_kelas'] ?></td>
				<td><?php echo $value['tingkat_kelas'] ?></td>
				<td>
					<a href="<?php echo base_url("admin/kelas/ubah/".$value['id_kelas']) ?>"class="btn btn-warning">Ubah</a>
					<a href="<?php echo base_url("admin/kelas/hapus/".$value['id_kelas']) ?>" class="btn btn-danger" onclick="return confirm('apakah yakin dihapus ?')">Hapus</a>
				</td>
			</tr>
		<?php endforeach ?>
	</tbody>
</table>
<a href="<?php echo base_url("admin/kelas/tambah") ?>" class="btn btn-primary">Tambah</a>