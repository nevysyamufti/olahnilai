<h3>UBAH KELAS</h3>
<form method="post">
	<div class="form-group">
		<label>Nama Jurusan</label>
		<select name="id_jurusan" class="form-control">
			<option value="">PILIH</option>
			<?php foreach ($jurusan as $key => $value): ?> 
				<option value="<?php echo $value['id_jurusan'] ?>" <?php echo set_select('id_jurusan', $value['id_jurusan'], (!empty($detail)AND $detail['id_jurusan']==$value['id_jurusan'] ? TRUE : FALSE)) ?>><?php echo $value['nama_jurusan'] ?></option>
				<?php endforeach ?>
		</select>
		<p><small><i class="text-danger"><?php echo form_error('id_jurusan') ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Nama Kelas</label>
		<input type="text" name="nama_kelas" class="form-control" value="<?php echo set_value('nama_kelas', $detail['nama_kelas']) ?>">
		<p><small><i class="text-danger"><?php echo form_error('nama_kelas') ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Tingkat</label>
		<input type="text" name="tingkat_kelas" class="form-control" value="<?php echo set_value('tingkat_kelas', $detail['tingkat_kelas']) ?>">
		<p><small><i class="text-danger"><?php echo form_error('nama_kelas') ?></i></small></p>
	</div>

	<div class="form-group">
		<button class="btn btn-primary">Simpan</button>
		<a href="<?php echo base_url("admin/kelas") ?>" class="btn btn-warning">Kembali</a>
	</div>

</form>