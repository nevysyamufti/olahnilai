<h3>TAMBAH DATA ADMIN</h3>
<hr>
<form method="post">
	<div class="form-group">
		<label>Nama Admin</label>
		<input type="" name="nama_admin" class="form-control" value="<?php echo set_value('nama_admin') ?>">
		<p><small><i class="text-danger"><?php echo form_error("nama_admin") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Email Admin</label>
		<input type="email" name="email_admin" class="form-control" value="<?php echo set_value('email_admin') ?>">
		<p><small><i class="text-danger"><?php echo form_error("email_admin") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Username Admin</label>
		<input type="" name="username_admin" class="form-control" value="<?php echo set_value('username_admin') ?>">
		<p><small><i class="text-danger"><?php echo form_error("username_admin") ?></i></small></p>
	</div>

	<div class="form-group">
		<label>Password</label>
		<input type="password" name="password_admin" class="form-control" value="<?php echo set_value('password_admin') ?>">
		<p><small><i class="text-danger"><?php echo form_error("password_admin") ?></i></small></p>
	</div>

	<div class="form-group">
		<button class="btn btn-primary">Simpan</button>
		<a href="<?php echo base_url("admin/admin") ?>" class="btn btn-warning">Kembali</a>
	</div>
</form>