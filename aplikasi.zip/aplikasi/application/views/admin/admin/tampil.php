<h3>DATA ADMIN</h3>
<hr>
<div class="table table-responsive">
	<table class="table table-bordered" id="thetable">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama Admin</th>
				<th>Email</th>
				<th>Username</th>
				<th>Password</th>
				<th>Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($administrator as $key => $value): ?>
			<tr>
				<td><?php echo $key+1 ?></td>
				<td><?php echo $value['nama_admin'] ?></td>
				<td><?php echo $value['email_admin'] ?></td>
				<td><?php echo $value['username_admin'] ?></td>
				<td><?php echo $value['password_admin'] ?></td>
				<td>
					<a href="<?php echo base_url("admin/admin/ubah/".$value['id_admin']) ?>" class="btn btn-warning btn-sm"><i class="fa fa-pencil"></i> Ubah</a>
					<a href="<?php echo base_url("admin/admin/hapus/".$value["id_admin"]) ?>"class="btn btn-danger btn-sm"><i class="fa fa-trash"></i> Hapus</a>
				</td>
			</tr>	
			<?php endforeach ?>			
		</tbody>
	</table>
	<div>
		<a href="<?php echo base_url("admin/admin/tambah") ?>" class="btn btn-primary">Tambah</a>
	</div>
</div>