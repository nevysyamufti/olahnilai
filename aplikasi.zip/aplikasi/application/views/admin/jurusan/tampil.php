<h3>DATA JURUSAN</h3>
<hr>
<div class="table table-responsive">
	<table class="table table-bordered" id="thetable">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama</th>
				<th>Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($jurusan as $key => $value): ?>
				<tr>
					<td><?php echo $key+1 ?></td>
					<td><?php echo $value['nama_jurusan'] ?></td>
					<td>
						<a href="<?php echo base_url("admin/jurusan/ubah/".$value['id_jurusan']) ?>" class="btn btn-primary">Ubah</a>
						<a href="<?php echo base_url("admin/jurusan/hapus/".$value['id_jurusan']) ?>" class="btn btn-primary" onclick="return confirm('apakah yakin menghapus ?')">Hapus</a>
					</td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>
</div>
<div>
	<a href="<?php echo base_url("admin/jurusan/tambah") ?>" class="btn btn-primary">Tambah</a>
</div>