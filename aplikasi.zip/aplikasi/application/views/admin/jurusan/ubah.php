<h3>Ubah Data</h3>

<form method="post">
	<div class="form-group">
		<label>Nama Jurusan</label>
		<input type="text" name="nama_jurusan" class="form-control" value="<?php echo set_value("nama_jurusan", $detail['nama_jurusan']) ?>">
		<p><small><i class="text-danger"><?php echo form_error("nama_jurusan") ?></i></small></p>
	</div>
	<div class="form-group">
		<button class="btn btn-primary">SIMPAN</button>
	</div>
</form>