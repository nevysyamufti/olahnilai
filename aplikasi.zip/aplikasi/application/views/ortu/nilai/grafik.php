<h3>Grafik Perkembangan Nilai Siswa</h3>
<hr>
<a href="<?php echo base_url("ortu/nilai") ?>" class="btn btn-info"><i class="fa fa-list-alt"></i>D</a>
<a href="<?php echo base_url("ortu/detailnilai") ?>" class="btn btn-info"><i class="fa fa-table"></i>D</a>
<a href="<?php echo base_url("ortu/grafik") ?>" class="btn btn-info"><i class="fa fa-bar-chart"></i>D</a>

<div id="letak_grafik" style="height: 500px;"></div>
<script type="text/javascript">
	$(function () {
		Highcharts.chart('letak_grafik', {
			chart:{
				type: 'column'
			},
			title: {
				text: 'Grafik Nilai Siswa'
			},
			xAxis: {
				categories: [
				<?php foreach ($nilai['kategori'] as $key => $value): ?>
					'<?php echo $value ?>',
				<?php endforeach ?>
				],
				crosshair: true
			},
			yAxis: {
				min: 0,
				title: {
					text: 'Nilai Rata-rata Akhir'
				}
			},
			tooltip:{
				headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
				pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' + '<td style="padding:0"><b>{point.y:.3f}</b></td></tr>',
				footerFormat: '</table>',
				shared: true,
				useHTML: true
			},
			plotOptions: {
			column: {
			pointPadding: 0.2,
			borderWidth: 0
		}
	},
	series: [
	<?php foreach ($nilai['seri'] as $semester => $value): ?>
		{
			name: '<?php echo $semester ?>',
			data: [
			<?php foreach ($value as $tahun => $nilai): ?>
				<?php echo $nilai ?>,
			<?php endforeach ?>
			]
		},
	<?php endforeach ?>
	]

});
});
</script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>