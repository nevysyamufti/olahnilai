<h3>Hasil Studi Siswa Per-semester</h3>
<hr>
<form class="form-inline">
	<div class="form-group">
		<label>Pilih Semester</label>
		<select class="form-control" name="id_semester">
			<?php foreach ($semester as $key => $value): ?> 
				<option value="<?php echo $value['id_semester'] ?>" <?php if($id_semester==$value['id_semester']){echo "selected";} ?>> <?php echo $value['nama_semester'] ?></option>
			<?php endforeach ?>
		</select>
	</div>

	<div class="form-group">
		<button class="btn btn-primary"> Pilih</button>
	</div>
</form>
<br>
<div class="table-responsive">
		<a href="<?php echo base_url("ortu/nilai") ?>" class="btn btn-info"><i class="fa fa-list-alt"></i>D</a>
		<a href="<?php echo base_url("ortu/detailnilai") ?>" class="btn btn-info"><i class="fa fa-table"></i>D</a>
		<a href="<?php echo base_url("ortu/grafik") ?>" class="btn btn-info"><i class="fa fa-bar-chart"></i>D</a>
	<table class="table table-bordered">
		<thead>
			<tr>
				<th rowspan="2" style="vertical-align: middle;">No</th>
				<th rowspan="2" style="vertical-align: middle;">Mapel</th>
				<th colspan="5" class="text-center">Nilai</th>
			</tr>
			<tr>
				<th>Tugas</th>
				<th>UTS</th>
				<th>UAS</th>
				<th>Praktek</th>
				<th>Nilai Akhir</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($nilai as $key => $value): ?>
				<tr>
					<td><?php echo $key+1 ?></td>
					<td><?php echo $value['nama_mapel'] ?></td>
					<td><?php echo $value['nilai_tugas'] ?></td>
					<td><?php echo $value['nilai_uts'] ?></td>
					<td><?php echo $value['nilai_uas'] ?></td>
					<td><?php echo $value['nilai_praktek'] ?></td>
					<td><?php echo $value['nilai_akhir'] ?></td>
				</tr>
			<?php endforeach ?>

		</tbody>
		<tfoot>
			<tr>
				<td colspan="6" class="text-right">Nilai Rata-Rata Akhir</td>
				<td><?php echo $nilai_rata_rata ?></td>
			</tr>
		</tfoot>
	</table>
	
</div>