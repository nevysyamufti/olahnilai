<h3>Tampil Absensi</h3>
<hr>
<form class="form-inline">
	<div class="form-group">
		<label>Pilih Semester</label>
		<select class="form-control" name="id_semester">
			<?php foreach ($semester as $key => $value): ?> 
				<option value="<?php echo $value['id_semester'] ?>" <?php if($id_semester==$value['id_semester']){echo "selected";} ?>> <?php echo $value['nama_semester'] ?></option>
			<?php endforeach ?>
		</select>
	</div>

	<div class="form-group">
		<button class="btn btn-primary"> Pilih</button>
	</div>
</form>
<br>
<div class="table-responsive">
	<table class="table table-bordered" id="thetable">
		<thead>
			<tr>
				<th rowspan="2" style="vertical-align: middle;">Tanggal</th>
				<th colspan="4" class="text-center">Absensi</th>
			</tr>
			<tr>
				<th>H</th>
				<th>I</th>
				<th>A</th>
				<th>S</th>
				
			</tr>
		</thead>
		<tbody>
			<?php foreach ($absensi as $key => $value): ?>
				<tr>
					<td><?php echo $value['tanggal_absensi'] ?></td>
					<td><?php if($value['status_absensi']=="Hadir"){echo "<span class='glyphicon glyphicon-check'></span>";}?></td>
					<td><?php if($value['status_absensi']=="Ijin"){echo "<span class='glyphicon glyphicon-check'></span>";}?></td>
					<td><?php if($value['status_absensi']=="Alpha"){echo "<span class='glyphicon glyphicon-check'></span>";}?></td>
					<td><?php if($value['status_absensi']=="Sakit"){echo "<span class='glyphicon glyphicon-check'></span>";}?></td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>
</div>
<p>AKUMULASI KETIDAKHADIRAN</p>
<div class="row">
	<div class="col-sm-6">
		<table class="table table-bordered">
			<?php foreach ($akumulasi as $key => $value): ?>
				<tr>
					<td>
						<div class="row">
							<div class="col-xs-8 text-uppercase">
								<?php echo $key ?>
								<span class="pull-right">:</span>
							</div>
							<div class="col-xs-4">
								<?php echo $value ?>
							</div>
						</div>
					</td>
				</tr>
			<?php endforeach ?>
		</table>
	</div>
</div>