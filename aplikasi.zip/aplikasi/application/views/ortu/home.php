<!DOCTYPE html>
<html>
<head>
	<title>Beranda</title>
</head>
<body>
	<div class="container">
		<div class="row">
			<img src="<?php echo base_url("assets/img/halo/".foto_pengaturan(1)) ?>" height="140px" alt="" class="img-rounded" style="display: block; margin: auto;">
			<h2 class="text-center" >SMA TAMAN MADYA JETIS YOGYAKARTA</h2>
			<p class="text-center">Taqwa, cerdas, terampil, sehat, merdeka, mandiri dan berbudi pekerti luhur.</p>
		</div>
	</div>
	<hr>
	<div class="row">
		<div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<div class="row">
						<div class="col-xs-3">
							<i class="fa fa-id-card fa-5x"></i>
						</div>
						<div class="col-lg-9 text-right">
							<!-- <div class="huge">1233</div> -->
							<div>Profil</div>
						</div>
					</div>
				</div>
				<a href="member.php">
					<div class="panel-footer">
						<span class="pull-left">Lihat Detail Profil</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
				</a>
			</div>
		</div>

		<div class="col-lg-4 col-md-6">
			<div class="panel panel-success">
				<div class="panel-heading">
					<div class="row">
						<div class="col-xs-3">
							<i class="fa fa-folder-open fa-5x"></i>
						</div>
						<div class="col-xs-9 text-right">
							<!-- <div class="huge">3423</div> -->
							<div>Penilaian</div>
						</div>
					</div>
				</div>
				<a href="<?php echo base_url("ortu/nilai") ?>">
					<div class="panel-footer">
						<span class="pull-left">Lihat nilai</span>
						<span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
						<div class="clearfix"></div>
					</div>
				</a>
			</div>
		</div>

		<div class="col-lg-4 col-md-6">
                        <div class="panel panel-info">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-print fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <!-- <div class="huge">3423</div> -->
                                        <div>Lihat Laporan</div>
                                    </div>
                                </div>
                            </div>
                            <a href="produk.php">
                                <div class="panel-footer">
                                    <span class="pull-left">Lihat laporan</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
	</body>
	</html>
