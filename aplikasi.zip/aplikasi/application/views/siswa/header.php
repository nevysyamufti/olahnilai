

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>Admin Penilaian</title>

	<!-- Bootstrap -->
	<link href="<?php echo base_url("assets/css/bootstrap.min.css") ?>" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@600&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url("assets/font-awesome-4.7.0/css/font-awesome.css") ?>">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/css/inadmin.css") ?>">
	<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
</head>
<body>

	<div id="wrapper">
		<nav class="navbar navbar-default">
			<div class="navbar-header">
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
				data-target=".sidebar-collapse" aria-expanded="false">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<a class="navbar-brand" href="#">Sistem Informasi Nilai</a>
		</div>
		<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
			<form class="navbar-form navbar-right" method="post" action="<?php echo base_url("siswa//welcome/ubah_session_tahun_ajaran") ?>">
				<div class="form-group">
					<select class="form-control" name="id_tahun_ajaran" onchange="submit()">
						<?php foreach (tahun_ajaran() as $key => $value): ?>
							<option value="<?php echo $value['id_tahun_ajaran'] ?>" <?php if($value['id_tahun_ajaran']==tahun_aktif()){echo "selected";} ?>><?php echo $value['tahun_ajaran'] ?></option>
						<?php endforeach ?>
					</select>
				</div>
			</form>
			
		</div>
	</nav> 

	<nav class="navbar-default navbar-side">
		<div class="sidebar-collapse">
			<div class="user">
				<a href="<?php echo base_url("siswa/profil") ?>">
					<img src="<?php echo base_url("assets/img/siswa/".foto_siswa()) ?>" alt="" class="img-rounded">
					<h3><?php echo nama_siswa() ?></h3>
					<p>Seorang Siswa</p>
				</a>
			</div>
			<ul class="nav" id="main-menu">
				<li> <a href="<?php echo base_url("siswa") ?>"><i class="fa fa-home"></i> Home</a> </li>
				<!-- <li><a href="<?php echo base_url("siswa/sikap") ?>">Sikap</a></li> -->
				<li><a href="<?php echo base_url("siswa/nilai") ?>">Nilai</a></li>
				<li><a href="<?php echo base_url("siswa/absensi") ?>">Kehadiran</a></li>
				<li><a href="<?php echo base_url("siswa/rapor") ?>">Rapor</a></li>
				<li> <a href="<?php echo base_url("siswa/profil") ?>"><i class="fa fa-user-circle"></i> Pengaturan Profil</a> </li>
				<li> <a href="<?php echo base_url("siswa/Logout") ?>"><i class="fa fa-sign-out"></i> Keluar</a> </li> 
			</ul>
		</div>
	</nav>

	<div id="page-wrapper">
		<div id="page-inner">