<h3>Tabulasi Nilai Siswa</h3>
<hr>
</form>
<div class="table-responsive">
	<a href="<?php echo base_url("siswa/nilai") ?>" class="btn btn-info"><i class="fa fa-list-alt"></i>D</a>
	<a href="<?php echo base_url("siswa/detailnilai") ?>" class="btn btn-info"><i class="fa fa-table"></i>D</a>
	<a href="<?php echo base_url("siswa/grafik") ?>" class="btn btn-info"><i class="fa fa-bar-chart"></i>D</a>
	<br><br>
	<table class="table table-bordered" id="thetable">
		<thead>
			<tr>
				<th>No</th>
				<th>Mata Pelajaran</th>
				<th>Semester</th>
				<th>Tugas</th>
				<th>UTS</th>
				<th>UAS</th>
				<th>Praktek</th>
				<th>KKM</th>
				<th>Nilai Akhir</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($detni as $key => $value): ?>
				<tr>
					<td><?php echo $key+1 ?></td>
					<td><?php echo $value['nama_mapel'] ?></td>
					<td><?php echo $value['nama_semester'] ?></td>
					<td><?php echo round($value['nilai_tugas']) ?></td>
					<td><?php echo round($value['nilai_uts']) ?></td>
					<td><?php echo round($value['nilai_uas']) ?></td>
					<td><?php echo round($value['nilai_praktek']) ?></td>
					<td><?php echo $value['kkm_mapel'] ?></td>
					<td><?php echo round($value['nilai_akhir']) ?></td>
				</tr>
			<?php endforeach ?>

		</tbody>
		<tfoot>
			<tr>
				<td colspan="8" class="text-right">Nilai Rata-Rata Akhir</td>
				<td><?php echo round($nilai_rata_rata) ?></td>
			</tr>
		</tfoot>
	</table>
	
</div>