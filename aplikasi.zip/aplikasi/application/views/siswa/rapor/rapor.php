<h3>Halaman Raport</h3>
<hr>
<form class="form-inline">
	<div class="form-group">
		<label>Pilih semester</label>
		<select class="form-control" name="id_semester">
			<?php foreach ($semester as $key => $value): ?>
				<option value="<?php echo $value['id_semester'] ?>" <?php if($id_semester==$value['id_semester']){echo "selected";} ?>><?php echo $value['nama_semester'] ?></option>
			<?php endforeach ?>
		</select>
	</div>
	<div class="form-group">
		<button class="btn btn-primary">PILIH</button>
	</div>
</form>
<hr>
<h3 class="text-center">Raport</h3>
<div>

	<!-- Nav tabs -->
	<ul class="nav nav-tabs" role="tablist">
		<li role="presentation" class="active"><a href="#home" aria-controls="home" role="tab" data-toggle="tab">Sikap</a></li>
		<li role="presentation"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Pengetahuan</a></li>
		<li role="presentation"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab">Ekstrakulikuler</a></li>
	</ul>

	<!-- Tab panes -->
	<div class="tab-content">
		<div role="tabpanel" class="tab-pane active" id="home">
			<div class="row" style="margin-top: 25px">
				<div class="col-xs-6">
					<table width="100%">
						<tr>
							<th width="35%">Nama Sekolah</th>
							<th width="2%">:</th>
							<td><?php echo isi_pengaturan(2) ?></td>
						</tr>
						<tr>
							<th>Alamat</th>
							<th>:</th>
							<td><?php echo isi_pengaturan(3) ?></td>
						</tr>
						<tr>
							<th>Nama Peserta Didik</th>
							<th>:</th>
							<td><?php echo $siswa['nama_siswa']; ?></td>
						</tr>
						<tr>
							<th>NISN</th>
							<th>:</th>
							<td><?php echo $siswa['nis_siswa']; ?></td>
						</tr>
					</table>
				</div>
				<div class="col-xs-5 col-xs-offset-1">
					<table width="100%">
						<tr>
							<th width="30%">Kelas</th>
							<th width="1%">:</th>
							<td><?php echo $siswa_tahun['nama_kelas']." ".$siswa_tahun['tingkat_kelas']; ?></td>
						</tr>
						<tr>
							<th>Semester</th>
							<th>:</th>
							<td><?php echo $semester_aktif['nama_semester']; ?></td>
						</tr>
						<tr>
							<th>Tahun Ajaran</th>
							<th>:</th>
							<td><?php echo $tahun_aktif['tahun_ajaran']; ?></td>
						</tr>
					</table>
				</div>
			</div>
			<hr>
			<p class="text-center">Pencapaian Peserta Didik</p>
			<p>A. SIKAP</p>
			<table class="table table-bordered">
				<thead>
					<tr>
						<th>Predikat</th>
						<th>Deskripsi</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><?php echo $nilai_sikap['keterangan_sikap'] ?></td>
						<td>
							<?php 
							if ($nilai_sikap['keterangan_sikap']=="Baik") {
								echo isi_pengaturan(4);
							} elseif ($nilai_sikap['keterangan_sikap']=="Cukup") {
								echo isi_pengaturan(5);
							} elseif ($nilai_sikap['keterangan_sikap']=="Kurang") {
								echo isi_pengaturan(6);
							}
							?>
						</td>
					</tr>
				</tbody>
			</table>
			<div class="row">
				<div class="col-xs-6 col-xs-offset-6 col-sm-4 col-sm-offset-8">
					<p>Yogyakarta, <?php echo tanggal_indonesia(date("Y-m-d")) ?></p>
					<p style="margin-bottom: 100px">Wali Kelas</p>
					<p><u><?php echo $wali_kelas['nama_guru'] ?></u></p>
					<p>NIP. <?php echo $wali_kelas['nip_guru'] ?></p>
				</div>
			</div>
		</div>
		<div role="tabpanel" class="tab-pane" id="profile">
			<div class="row" style="margin-top: 25px">
				<div class="col-xs-6">
					<table width="100%">
						<tr>
							<th width="35%">Nama Sekolah</th>
							<th width="2%">:</th>
							<td><?php echo isi_pengaturan(2) ?></td>
						</tr>
						<tr>
							<th>Alamat</th>
							<th>:</th>
							<td><?php echo isi_pengaturan(3) ?></td>
						</tr>
						<tr>
							<th>Nama Peserta Didik</th>
							<th>:</th>
							<td><?php echo $siswa['nama_siswa']; ?></td>
						</tr>
						<tr>
							<th>NISN</th>
							<th>:</th>
							<td><?php echo $siswa['nis_siswa']; ?></td>
						</tr>
					</table>
				</div>
				<div class="col-xs-5 col-xs-offset-1">
					<table width="100%">
						<tr>
							<th width="30%">Kelas</th>
							<th width="1%">:</th>
							<td><?php echo $siswa_tahun['nama_kelas']." ".$siswa_tahun['tingkat_kelas']; ?></td>
						</tr>
						<tr>
							<th>Semester</th>
							<th>:</th>
							<td><?php echo $semester_aktif['nama_semester']; ?></td>
						</tr>
						<tr>
							<th>Tahun Ajaran</th>
							<th>:</th>
							<td><?php echo $tahun_aktif['tahun_ajaran']; ?></td>
						</tr>
					</table>
				</div>
			</div>
			<hr>
			<p>B. PENGETAHUAN</p>
			<p>Kriteria ketuntasaan minimal = 70</p>
			<table class="table table-bordered">
				<thead>
					<tr>
						<th>No</th>
						<th>Mata Pelajaran</th>
						<th>Nilai</th>
						<th>Predikat</th>
						<th>Deskripsi</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($nilai_pengetahuan as $kelompok => $value_1):?>
						<tr>
							<td colspan="5"><?php echo deskripsi_kelompok($kelompok) ?></td>
						</tr>
						<?php foreach ($value_1 as $jurusan => $value_2): ?>
							<?php if ($jurusan!=="Umum"): ?>
								<tr>
									<td colspan="5"><?php echo deskripsi_peminatan($jurusan) ?></td>
								</tr>
							<?php endif ?>
							<?php foreach ($value_2 as $mapel => $value_3): ?>
								<tr>
									<td><?php echo $value_3['urutan_mapel'] ?></td>
									<td><?php echo $value_3['nama_mapel'] ?></td>
									<td><?php echo round($value_3['nilai_akhir']) ?></td>
									<td><?php echo konversi_nilai($value_3['nilai_akhir']) ?></td>
									<td><?php echo deskripsi_nilai($value_3['nilai_akhir'], $value_3['id_mapel']) ?></td>
								</tr>
							<?php endforeach ?>
						<?php endforeach ?>						
					<?php endforeach ?>
				</tbody>
			</table>
			<div class="row">
				<div class="col-xs-6 col-xs-offset-6 col-sm-4 col-sm-offset-8">
					<p>Yogyakarta, <?php echo tanggal_indonesia(date("Y-m-d")) ?></p>
					<p style="margin-bottom: 100px">Wali Kelas</p>
					<p><u><?php echo $wali_kelas['nama_guru'] ?></u></p>
					<p>NIP. <?php echo $wali_kelas['nip_guru'] ?></p>
				</div>
			</div>
		</div>
		<div role="tabpanel" class="tab-pane" id="messages">
			<div class="row" style="margin-top: 25px">
				<div class="col-xs-6">
					<table width="100%">
						<tr>
							<th width="35%">Nama Sekolah</th>
							<th width="2%">:</th>
							<td><?php echo isi_pengaturan(2) ?></td>
						</tr>
						<tr>
							<th>Alamat</th>
							<th>:</th>
							<td><?php echo isi_pengaturan(3) ?></td>
						</tr>
						<tr>
							<th>Nama Peserta Didik</th>
							<th>:</th>
							<td><?php echo $siswa['nama_siswa']; ?></td>
						</tr>
						<tr>
							<th>NISN</th>
							<th>:</th>
							<td><?php echo $siswa['nis_siswa']; ?></td>
						</tr>
					</table>
				</div>
				<div class="col-xs-5 col-xs-offset-1">
					<table width="100%">
						<tr>
							<th width="30%">Kelas</th>
							<th width="1%">:</th>
							<td><?php echo $siswa_tahun['nama_kelas']." ".$siswa_tahun['tingkat_kelas']; ?></td>
						</tr>
						<tr>
							<th>Semester</th>
							<th>:</th>
							<td><?php echo $semester_aktif['nama_semester']; ?></td>
						</tr>
						<tr>
							<th>Tahun Ajaran</th>
							<th>:</th>
							<td><?php echo $tahun_aktif['tahun_ajaran']; ?></td>
						</tr>
					</table>
				</div>
			</div>
			<hr>
			<p>C. EKSTRAKULIKULER</p>
			<table class="table table-bordered">
				<thead>
					<tr>
						<th>No</th>
						<th>Keterangan Ekstrakulikuler</th>
						<th>Predikat</th>
						<th>Keterangan</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($nilai_ekstra as $key => $value) : ?>
						<tr>
							<td><?php echo $key+=1 ?></td>
							<td><?php echo $value['nama_ekstra'] ?></td>
							<td><?php echo $value['predikat_nilai_ekstra'] ?></td>
							<td><?php echo deskripsi_ekstra($value['predikat_nilai_ekstra'], $value['id_ekstra']) ?></td>

						</tr>
					<?php endforeach ?>
				</tbody>
			</table>

			<p>D. KETIDAKHADIRAN</p>
			<div class="row">
				<div class="col-sm-6">
					<table class="table table-bordered">
						<?php foreach ($absensi as $key => $value): ?>
							<tr>
								<td>
									<div class="row">
										<div class="col-xs-8 text-uppercase">
											<?php echo $key ?>
											<span class="pull-right">:</span>
										</div>
										<div class="col-xs-4">
											<?php echo $value ?>
										</div>
									</div>
								</td>
							</tr>
						<?php endforeach ?>
					</table>
				</div>
			</div>
			<p>E. CATATAN WALI KELAS</p>
			<div class="panel panel-default">
				<div class="panel-body">
					<?php echo $nilai_sikap['catatan_wali_kelas'] ?>
				</div>
			</div>
			<p>F. TANGGAPAN ORANGTUA/WALI SISWA</p>
			<div class="panel panel-default">
				<div class="panel-body" style="padding-bottom: 50px;">
					
				</div>
			</div>

			<p>KEPUTUSAN :</p>
			<P><?php echo $keputusan ?></P>
			<small><i>*) Coret yang tidak perlu</i></small>

			<div class="row text-center" style="margin-top: 100px;">
				<div class="col-xs-4">
					<p>Mengetahui</p>
					<p style="margin-bottom: 100px;">Orang Tua / Wali</p>
					<p>......................</p>
				</div>
				<div class="col-xs-4 col-xs-offset-4">
					<p>Yogyakarta, <?php echo tanggal_indonesia(date("Y-m-d")) ?></p>
					<p style="margin-bottom: 100px">Wali Kelas</p>
					<p><u><?php echo $wali_kelas['nama_guru'] ?></u></p>
					<p>NIP. <?php echo $wali_kelas['nip_guru'] ?></p>
				</div>
			</div>
			<div class="row text-center">
				<div class="col-xs-4 col-xs-offset-4">
					<p>Mengetahui</p>
					<p style="margin-bottom: 100px;">Kepala Sekolah</p>
					<p><u><?php echo $kepala_sekolah['nama_kepala_sekolah'] ?></u></p>
					<p>NIP. <?php echo $kepala_sekolah['nip_kepala_sekolah'] ?></p>
				</div>
			</div>
		</div>
	</div>
</div>