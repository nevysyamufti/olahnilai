<h3>UBAH PASWORD</h3>
<hr>
<div class="container">
	<div class="row">
		<div class="col-sm-8 col-sm-6">
			<div class="panel panel-default" style="margin-bottom: 100px;" >
				<div class="panel-body">

					<form class="form-horizontal" method="post">
						<div class="form-group">
							<label class="col-sm-2" >Password Lama</label>
							<div class="col-sm-10">
								<input type="password" name="password_lama" class="form-control" value="<?php echo set_value("password_lama") ?>">
								<?php if($pesan=="pesan_1"): ?>
									<p class="text-danger"><small><i>*Password lama salah</i></small></p>
								<?php endif ?>
							</div>
						</div>

						<div class="form-group">
							<label class="col-sm-2">Password Baru</label>
							<div class="col-sm-10">
								<input type="password" name="password_baru" class="form-control" value="<?php echo set_value("password_baru") ?>">
								<?php if ($pesan=="pesan_2"): ?>
									<p class="text-danger"><small><i>*Password baru harus diidi</i></small></p>
								<?php endif ?>
							</div>
						</div>

						<div class="form-group">
							<label class="col-sm-2">Konfirmasi Password Baru</label>
							<div class="col-sm-10">
								<input type="password" name="password_konfirmasi" class="form-control" value="<?php echo set_value("password_konfirmasi") ?>">
								<?php if ($pesan=="pesan_3"): ?>
									<p class="text-danger"><small><i>*Password konfirmasi harus sama dengan password baru</i></small></p>
								<?php endif ?>
							</div>
						</div>

						<div class="form-group">
							<div class="col-sm-10">
								<button class="btn btn-primary">Ganti Password</button>
								<a href="<?php echo base_url("siswa/profil") ?>" class="btn btn-warning">Kembali</a>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>