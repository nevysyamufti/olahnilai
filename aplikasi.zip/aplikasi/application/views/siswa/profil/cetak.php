<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
	<title>Login</title>

	<!-- Bootstrap -->
	<link href="<?php echo base_url("assets/css/bootstrap.min.css") ?>" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@600&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo base_url("assets/font-awesome-4.7.0/css/font-awesome.css") ?>">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo base_url("assets/css/inadmin.css") ?>">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-xs-2 col-xs-offeset-2 text-right">
				<img src="<?php echo base_url("assets/img/halo/logo6.png") ?>" width="50%" align="right" style="display: block; margin-left: auto; margin-right: auto; width: 70px; clear: both;">
			</div>

			<div class="col-xs-8 text-center">
				<p class="text-uppercase">
					Sekolah Menengah Atas (SMA) Swasta
					<br>
					Taman Madya Jetis
					<br>
					Tahun Pelajaran <?php echo $tahun['tahun_ajaran'] ?>
				</p>
			</div>
		</div>
	</div>
	<div style="margin: 50px 25px 50px 25px;">
		<table width="100%">
			<tr>
				<td width="3%">I</td>
				<td colspan="3">DATA PRIBADI</td>
			</tr>
			<tr>
				<td></td>
				<td>NISN</td>
				<td>:</td>
				<td><?php echo $siswa['nis_siswa'] ?></td>
			</tr>
			<tr>
				<td></td>
				<td width="25%">Nama Lengkap</td>
				<td width="1%">:</td>
				<td><?php echo $siswa['nama_siswa'] ?></td>
			</tr>
			<tr>
				<td></td>
				<td>Tempat, tanggal lahir</td>
				<td>:</td>
				<td><?php echo $siswa['tempat_lahir_siswa'].", ".tanggal_indonesia($siswa['tanggal_lahir_siswa']) ?></td>
			</tr>
			<tr>
				<td></td>
				<td>Alamat Peserta Didik</td>
				<td>:</td>
				<td><?php echo $siswa['alamat_siswa'] ?></td>
			</tr>
			<tr>
				<td></td>
				<td>Jenis Kelamin</td>
				<td>:</td>
				<td><?php echo $siswa['jk_siswa'] ?></td>
			</tr>
			<tr>
				<td></td>
				<td>Sekolah Asal</td>
				<td>:</td>
				<td><?php echo $siswa['sekolah_asal'] ?></td>
			</tr>
			<tr>
				<td></td>
				<td>Agama</td>
				<td>:</td>
				<td><?php echo $siswa['agama_siswa'] ?></td>
			</tr>
			<tr>
				<td></td>
				<td>Nomor HP</td>
				<td>:</td>
				<td><?php echo $siswa['notelp_siswa'] ?></td>
			</tr>
		</table>

		<table width="100%" style="margin-top: 25px">
			<tr>
				<td width="3%">II</td>
				<td>DATA KELUARGA</td>
			</tr>
			<tr>
				<td></td>
				<td>
					<table class="table table-bordered">
						<thead>
							<tr>
								<th>No</th>
								<th>Data</th>
								<th>Nama</th>
								<th>Telp</th>
								<th>Pendidikan</th>
								<th>Kerja</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td>1</td>
								<td>Ayah</td>
								<td><?php echo $siswa['ayah_siswa'] ?></td>
								<td><?php echo $siswa['notelp_ayah'] ?></td>
								<td><?php echo $siswa['pendidikan_ayah'] ?></td>
								<td><?php echo $siswa['kerja_ayah'] ?></td>
							</tr>
							<tr>
								<td>2</td>
								<td>Ibu</td>
								<td><?php echo $siswa['ibu_siswa'] ?></td>
								<td><?php echo $siswa['notelp_ibu'] ?></td>
								<td><?php echo $siswa['pendidikan_ibu'] ?></td>
								<td><?php echo $siswa['kerja_ibu'] ?></td>
							</tr>
						</tbody>
					</table>
					<p>Saya menyatakan bahwa data profil pribadi yang saya tanda tangani ini benar adanya untuk dipakai sebagai acuan.</p>
					<div class="row text-center" style="margin-top: 50px;">
						<div class="col-xs-12 col-xs-offset-4">
							<p>Yogyakarta, <?php echo tanggal_indonesia(date("Y-m-d")) ?></p>
							<p style="margin-bottom: 100px">Siswa bersangkutan</p>
							<p><u><?php echo $siswa['nama_siswa'] ?></u></p>
							<p>NIP. <?php echo $siswa['nis_siswa'] ?></p>
						</div>
					</div>
				</td>
			</tr>
		</table>
		<a onclick="print()" class="btn btn-primary hidden-print">Cetak</a>
	</div>
</body>
</html>