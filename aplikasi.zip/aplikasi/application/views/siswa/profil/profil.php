<h3>PROFIL SISWA</h3>
<hr>
<table class="table table-bordered">	
	<tr>
		<th width="25%">Nomor Induk Siswa</th>
		<th width="1%">:</th>
		<td><?php echo $siswa['nis_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Nama Siswa</th>
		<th>:</th>
		<td><?php echo $siswa['nama_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Alamat Siswa</th>
		<th>:</th>
		<td><?php echo $siswa['alamat_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Tempat Tanggal Siswa</th>
		<th>:</th>
		<td><?php echo $siswa['tempat_lahir_siswa'].", ".tanggal_indonesia($siswa['tanggal_lahir_siswa']) ?></td>
	</tr>
	<tr>	
		<th>Jenis Kelamin</th>
		<th>:</th>
		<td><?php echo $siswa['jk_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Nomor Telpon</th>
		<th>:</th>
		<td><?php echo $siswa['notelp_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Sekolah Asal</th>
		<th>:</th>
		<td><?php echo $siswa['sekolah_asal']?>  
		<!-- <?php  if(isset($siswa[$value['id_siswa']]) AND $siswa[$value['id_siswa']]['sekolah_asal']=='Hadir') ?> -->
		</td>
	</tr>
	<tr>	
		<th>Agama</th>
		<th>:</th>
		<td><?php echo $siswa['agama_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Foto Siswa</th>
		<th>:</th>
		<td>
			<img src="<?php echo base_url("assets/img/siswa/".$siswa['foto_siswa']) ?>" width="100px">
		</td>
	</tr>
	<tr>	
		<th>Ayah Siswa</th>
		<th>:</th>
		<td><?php echo $siswa['ayah_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Ibu Siswa</th>
		<th>:</th>
		<td><?php echo $siswa['ibu_siswa'] ?></td>
	</tr>
	<tr>	
		<th>No Telp Ayah</th>
		<th>:</th>
		<td><?php echo $siswa['notelp_ayah'] ?></td>
	</tr>
	<tr>	
		<th>No Telp Ibu</th>
		<th>:</th>
		<td><?php echo $siswa['notelp_ibu'] ?></td>
	</tr>
	<tr>	
		<th>Pendidikan Ayah</th>
		<th>:</th>
		<td><?php echo $siswa['pendidikan_ayah'] ?></td>
	</tr>
	<tr>	
		<th>Pendidikan Ibu</th>
		<th>:</th>
		<td><?php echo $siswa['pendidikan_ibu'] ?></td>
	</tr>
	<tr>	
		<th>Kerja Ayah</th>
		<th>:</th>
		<td><?php echo $siswa['kerja_ayah'] ?></td>
	</tr>
	<tr>	
		<th>Kerja Ibu</th>
		<th>:</th>
		<td><?php echo $siswa['kerja_ibu'] ?></td>
	</tr>
	<tr>	
		<th>Username Siswa</th>
		<th>:</th>
		<td><?php echo $siswa['username_siswa'] ?></td>
	</tr>
	<tr>	
		<th>Password Siswa</th>
		<th>:</th>
		<td><?php echo $siswa['password_siswa'] ?></td>
	</tr>

</table>
<a href="<?php echo base_url("siswa/profil/ubah_profil") ?>" class="btn btn-warning">Ubah</a>
<a href="<?php echo base_url("siswa/profil/ubah_password") ?>" class="btn btn-info">Ubah Password</a>
<a href="<?php echo base_url("siswa/profil/cetak") ?>" class="btn btn-primary" target="blank()">Print</a>