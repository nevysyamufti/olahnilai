<h3>UBAH DATA</h3>
<form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label>Nomor Induk Siswa</label>
		<input type="" name="nis_siswa" class="form-control" value="<?php echo $siswa['nis_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Nama Siswa</label>
		<input type="" name="nama_siswa" class="form-control" value="<?php echo $siswa['nama_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Alamat Siswa</label>
		<input type="text" name="alamat_siswa" class="form-control" value="<?php echo $siswa['alamat_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Tempat Lahir Siswa</label>
		<input type="" name="tempat_lahir_siswa" class="form-control" value="<?php echo $siswa['tempat_lahir_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Tanggal Lahir Siswa</label>
		<input type="date" name="tanggal_lahir_siswa" class="form-control" value="<?php echo $siswa['tanggal_lahir_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Jenis Kelamin Siswa</label>
		<select name="jk_siswa" class="form-control" value="<?php echo $siswa['jk_siswa'] ?>">
			<option value="">Pilih</option>
			<option value="Laki-laki" <?php if ($siswa['jk_siswa']=='Laki-laki') {echo "selected" ;
			} ?>>Laki</option>
			<option value="Perempuan" <?php if ($siswa['jk_siswa']=='Perempuan') {echo "selected" ;
			} ?>>Perempuan</option>
		</select>
	</div>

	<div class="form-group">
		<label>Nomor Telp Siswa</label>
		<input type="" name="notelp_siswa" class="form-control" value="<?php echo $siswa['notelp_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Sekolah Asal</label>
		<input type="" name="sekolah_asal" class="form-control" value="<?php echo $siswa['sekolah_asal'] ?>">
	</div>

	<div class="form-group">
		<label>Agama</label>
		<select name="agama_siswa" class="form-control" value="<?php echo $siswa['agama_siswa'] ?>">
			<option value="">Pilih</option>
			<option value="Islam" <?php if($siswa['agama_siswa']=='Islam'){echo "selected";} ?>>Islam</option>
			<option value="Hindu" <?php if($siswa['agama_siswa']=='Hindu'){echo "selected";} ?>>Hindu</option>
			<option value="Buddha" <?php if($siswa['agama_siswa']=='Buddha'){echo "selected";} ?>>Budha</option>
			<option value="Katolik" <?php if($siswa['agama_siswa']=='Katolik'){echo "selected";} ?>>Katolik</option>
			<option value="Protestan" <?php if($siswa['agama_siswa']=='Protestan'){echo "selected";} ?>>Protestan</option>
			<option value="Khonghucu" <?php if($siswa['agama_siswa']=='Khonghucu'){echo "selected";} ?>>Khonghucu</option>
		</select>
	</div>

	<div class="form-group">
		<label>Foto Siswa</label>
		<br>	
		<img src="<?php echo base_url("./assets/img/siswa/".$siswa['foto_siswa']) ?>" width="200px">
		<input type="file" name="foto_siswa" class="form-control" value="<?php echo $siswa['foto_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Ayah Siswa</label>
		<input type="" name="ayah_siswa" class="form-control" value="<?php echo $siswa['ayah_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>Ibu Siswa</label>
		<input type="" name="ibu_siswa" class="form-control" value="<?php echo $siswa['ibu_siswa'] ?>">
	</div>

	<div class="form-group">
		<label>No Telp Ayah</label>
		<input type="" name="notelp_ayah" class="form-control" value="<?php echo $siswa['notelp_ayah'] ?>">
	</div>

	<div class="form-group">
		<label>No Telp Ibu</label>
		<input type="" name="notelp_ibu" class="form-control" value="<?php echo $siswa['notelp_ibu'] ?>">
	</div>

	<div class="form-group">
		<label>Pendidikan Ayah</label>
		<input type="" name="pendidikan_ayah" class="form-control" value="<?php echo $siswa['pendidikan_ayah'] ?>">
	</div>

	<div class="form-group">
		<label>Pendidikan Ibu</label>
		<input type="" name="pendidikan_ibu" class="form-control" value="<?php echo $siswa['pendidikan_ibu'] ?>">
	</div>

	<div class="form-group">
		<label>Kerja Ayah</label>
		<input type="" name="kerja_ayah" class="form-control" value="<?php echo $siswa['kerja_ayah'] ?>">
	</div>

	<div class="form-group">
		<label>Kerja Ibu</label>
		<input type="" name="kerja_ibu" class="form-control" value="<?php echo $siswa['kerja_ibu'] ?>">
	</div>

	<div class="form-group">
		<label>Username Siswa</label>
		<input type="" name="username_siswa" class="form-control" value="<?php echo $siswa['username_siswa'] ?>">
	</div>
	<div>
		<button class="btn btn-primary">Simpan</button>
		<a href="<?php echo base_url("siswa/profil") ?>" class="btn btn-warning">Kembali</a>
	</div>
</form>