<h3>Grafik</h3>

<form method="post" class="form-inline">
	<div class="form-group">
		<select name="id_tahun" class="form-control">
			<?php foreach ($tahun as $key => $value): ?>
				<option value="<?php echo $value['id_tahun_ajaran'] ?>" <?php if($id_tahun==$value['id_tahun_ajaran']){echo "selected";} ?>><?php echo $value['tahun_ajaran'] ?></option>
			<?php endforeach ?>
		</select>
	</div>

	<div class="form-group">
		<select name="id_semester" class="form-control">
			<?php foreach ($semester as $key => $value): ?>
				<option value="<?php echo $value['id_semester'] ?>" <?php if($id_semester==$value['id_semester']){echo "selected";} ?>> <?php echo $value['nama_semester'] ?></option>
			<?php endforeach ?>
		</select>
	</div>

	<div class="form-group">
		<button class="btn btn-primary">Lihat Grafik</button>
	</div>
</form>

<div id="letak_grafik" style="height: 500px;"></div>
<script type="text/javascript">
	$(function () {
		Highcharts.chart('letak_grafik', {
			chart:{
				type: 'column'
			},
			title: {
				text: 'Grafik Nilai Siswa'
			},
			xAxis: {
				categories: [
				<?php foreach ($nilai as $key => $value): ?>
					'<?php echo $key ?>',
				<?php endforeach ?>
				],
				crosshair: true
			},
			yAxis: {
				min: 0,
				title: {
					text: 'Nilai Rata-rata Akhir'
				}
			},
			tooltip:{
				headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
				pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' + '<td style="padding:0"><b>{point.y:.2f}</b></td></tr>',
				footerFormat: '</table>',
				shared: true,
				useHTML: true
			},
			plotOptions: {
				column: {
					pointPadding: 0.2,
					borderWidth: 0
				}
			},
			series: [
			{
				name: 'Data Nilai Siswa Kelas <?php echo $kelas ['nama_kelas']." ".$kelas['tingkat_kelas'] ?>',
				data: [
				<?php foreach ($nilai as $key => $value): ?>
					<?php echo $value ?>,
				<?php endforeach ?>
				]
			},
			]

		});
	});
</script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>

<p>Presentase Nilai Berdasarkan Rata-Rata 1 Kelas</p>
<ul>
	<li>Siswa yang berada diatas rata-rata : <?php echo round($persen['diatas']) ?>%</li>
	<li>Siswa yang berada dibawah rata-rata : <?php echo round($persen['dibawah']) ?>%</li>
</ul>

<p>Urutan Nilai</p>
<?php arsort($nilai) ?>
<ul>
	<?php foreach ($nilai as $key => $value): ?>
		<li><?php echo $key ?></li>
	<?php endforeach ?>
</ul>