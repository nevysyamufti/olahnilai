<h3>Penilaian Ekstrakulikuler</h3>
<hr>

 <?php if (empty($siswa)): ?>
 	<div class="alert alert-info">Anda Bukan Wali Kelas</div>
 <?php else: ?>

<form method="post">
	<div class="table-responsive">
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>No</th>
					<th>NIS</th>
					<th>Nama</th>
					<th>Keterangan Keaktifan</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($siswa as $key => $value): ?>
					<tr>
						<td><?php echo $key+1 ?></td>
						<td><?php echo $value['nis_siswa'] ?></td>
						<td><?php echo $value['nama_siswa'] ?></td>
						<td>
							<?php foreach ($ekstra as $key_k => $value_k): ?>
								<?php $isk = $value['id_siswa_kelas'] ?>
								<?php $ie = $value_k['id_ekstra'] ?>
								<div class="row">
									<div class="col-sm-6">
										<div class="checkbox">
											<label>
												<input type="checkbox" name="id_ekstra[<?php echo $value['id_siswa_kelas'] ?>][<?php echo $value_k['id_ekstra'] ?>]" <?php if(isset($nilai[$isk][$ie])){echo "checked";} ?>> <?php echo $value_k['nama_ekstra'] ?>
											</label>
										</div>
									</div>
									<div class="col-sm-6">
										<div class="form-group">
											<select name="predikat_nilai_ekstra[<?php echo $value['id_siswa_kelas'] ?>][<?php echo $value_k['id_ekstra'] ?>]" class="form-control">
												<option value="">Pilih Predikat</option>
												<option value="Sangat Baik" <?php if(isset($nilai[$isk][$ie]) AND $nilai[$isk][$ie]['predikat_nilai_ekstra'] == "Sangat Baik"){echo "selected";} ?>>Sangat Baik</option>
												<option value="Baik" <?php if(isset($nilai[$isk][$ie])AND $nilai[$isk][$ie]['predikat_nilai_ekstra'] == "Baik"){echo "selected";} ?>>Baik</option>
												<option value="Cukup" <?php if(isset($nilai[$isk][$ie])AND $nilai[$isk][$ie]['predikat_nilai_ekstra'] == "Cukup"){echo "selected";} ?>>Cukup</option>
												<option value="Kurang" <?php if(isset($nilai[$isk][$ie])AND $nilai[$isk][$ie]['predikat_nilai_ekstra'] == "Kurang"){echo "selected";} ?>>Kurang</option>
											</select>
										</div>
									</div>
								</div>
							<?php endforeach ?>
						</td>
					</tr>
					<!-- sebelum ada isset untuk data yang sudah ada saja -->
					<!-- <?php if($ekstra[$value['id_siswa_kelas']]['keterangan_ekstra']=='Aktif'){echo "checked";} ?>> -->
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
	<div class="form-group">
		<button class="btn btn-primary"> Simpan Ekstra </button>
	</div>
</form
<?php endif ?>