<h3>Halaman Rapor Siswa</h3>
<hr>
<!-- untuk memberi notifikasi bahwa bukan wali kelas -->
 <?php if (empty($siswa)): ?>
 	<div class="alert alert-info">Anda Bukan Wali Kelas</div>
 <?php else: ?>

<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>No</th>
				<th>NIS</th>
				<th>Nama Siswa</th>
				<?php foreach ($semester as $key => $value): ?>
					<th><?php echo $value['nama_semester'] ?></th>
				<?php endforeach ?>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($siswa as $key => $value): ?>
				<tr>
					<td><?php echo $key+=1 ?></td>
					<td><?php echo $value['nis_siswa'] ?></td>
					<td><?php echo $value['nama_siswa'] ?></td>
					<?php foreach ($semester as $key => $value_s): ?>
						<td>
							<a href="<?php echo base_url("guru/rapor/detail/".$value['id_siswa_kelas']."/".$value_s['id_semester']) ?>" class="btn btn-info">Rapor</a>
							<a href="<?php echo base_url("guru/rapor/cetak/".$value['id_siswa_kelas']."/".$value_s['id_semester']) ?>" class="btn btn-info">Cetak</a>
						</td>
					<?php endforeach ?>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>
</div>
<?php endif ?>