<h3>Data Mengajar</h3>

<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>No</th>
				<th>Kelas</th>
				<th>Tingkat Kelas</th>
				<th>Mapel</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($detailguru as $key => $value): ?>
			<tr>
				<td><?php echo $key+1 ?></td>
				<td><?php echo $value['nama_kelas'] ?></td>
				<td><?php echo $value['tingkat_kelas'] ?></td>
				<td><?php echo $value['nama_mapel'] ?></td>
			</tr>
			<?php endforeach ?>
		</tbody>
	</table>
</div>