<h3>UBAH PROFIL GURU</h3>
<hr>
<form method="post" enctype="multipart/form-data">
	<div class="form-group">
		<label>Nomor Induk Pegawai</label>
		<input type="" name="nip_guru" class="form-control" value="<?php echo $guru['nip_guru'] ?>">
	</div>

	<div class="form-group">
		<label>Nama Guru</label>
		<input type="" name="nama_guru" class="form-control" value="<?php echo $guru['nama_guru'] ?>">
	</div>	

	<div class="form-group">
		<label>Alamat Guru</label>
		<input type="text" name="alamat_guru" class="form-control" value="<?php echo $guru['alamat_guru'] ?>">
	</div>

	<div class="form-group">
		<label>Tempat Lahir Guru</label>
		<input type="" name="tempat_lahir_guru" class="form-control" value="<?php echo $guru['tempat_lahir_guru'] ?>">
	</div>

	<div class="form-group">
		<label>Tanggal Lahir Guru</label>
		<input type="date" name="tanggal_lahir_guru" class="form-control" value="<?php echo $guru['tanggal_lahir_guru'] ?>">
	</div>

	<div class="form-group">
		<label>Jenis Kelamin Guru</label>
		<select name="jk_guru" class="form-control" value="<?php echo $guru['jk_guru'] ?>">
			<option value="">Pilih</option>
			<option value="Laki-laki" <?php if ($guru['jk_guru']=='Laki-laki') {echo "selected" ;
			} ?>>Laki</option>
			<option value="Perempuan" <?php if ($guru['jk_guru']=='Perempuan') {echo "selected" ;
			} ?>>Perempuan</option>
		</select>
	</div>

	<div class="form-group">
		<label>Agama</label>
		<select name="agama_guru" class="form-control" value="<?php echo $guru['agama_guru'] ?>">
			<option value="">Pilih</option>
			<option value="Islam" <?php if($guru['agama_guru']=='Islam'){echo "selected";} ?>>Islam</option>
			<option value="Hindu" <?php if($guru['agama_guru']=='Hindu'){echo "selected";} ?>>Hindu</option>
			<option value="Buddha" <?php if($guru['agama_guru']=='Buddha'){echo "selected";} ?>>Budha</option>
			<option value="Katolik" <?php if($guru['agama_guru']=='Katolik'){echo "selected";} ?>>Katolik</option>
			<option value="Protestan" <?php if($guru['agama_guru']=='Protestan'){echo "selected";} ?>>Protestan</option>
			<option value="Khonghucu" <?php if($guru['agama_guru']=='Khonghucu'){echo "selected";} ?>>Khonghucu</option>
		</select>
	</div>

	<div class="form-group">
		<label>Pendidikan Guru</label>
		<input type="" name="pendidikan_guru" class="form-control" value="<?php echo $guru['pendidikan_guru'] ?>">
	</div>

	<div class="form-group">
		<label>Nomor Telp Guru</label>
		<input type="" name="notelp_guru" class="form-control" value="<?php echo $guru['notelp_guru'] ?>">
	</div>

	<div class="form-group">
		<label>Foto Guru</label>
		<br>	
		<img src="<?php echo base_url("./assets/img/guru/".$guru['foto_guru']) ?>" width="400px">
		<input type="file" name="foto_guru" class="form-control" value="<?php echo $guru['foto_guru'] ?>">
	</div>

	<div class="form-group">
		<label>Username Guru</label>
		<input type="" name="username_guru" class="form-control" value="<?php echo $guru['username_guru'] ?>">
	</div>

	<div>
		<button class="btn btn-primary">Simpan</button>
		<a href="<?php echo base_url("guru/profil") ?>" class="btn btn-warning">Kembali</a>
	</div>
</form>