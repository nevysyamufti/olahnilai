<h3>PROFIL GURU</h3>
<hr>
<table class="table table-bordered">	
	<tr>
		<th width="25%">Nomor Induk Pegawai</th>
		<th width="1%">:</th>
		<td><?php echo $guru['nip_guru'] ?></td>
	</tr>
	<tr>	
		<th>Nama Guru</th>
		<th>:</th>
		<td><?php echo $guru['nama_guru'] ?></td>
	</tr>
	<tr>	
		<th>Alamat Guru</th>
		<th>:</th>
		<td><?php echo $guru['alamat_guru'] ?></td>
	</tr>
	<tr>	
		<th>Tempat, Lahir Guru</th>
		<th>:</th>
		<td><?php echo $guru['tempat_lahir_guru'].", ".tanggal_indonesia($guru['tanggal_lahir_guru']) ?></td>
	</tr>
	<!-- <tr>	
		<th>Tanggal Lahir Guru</th>
		<th>:</th>
		<td><?php echo $guru['tanggal_lahir_guru'] ?></td>
	</tr> -->
	<tr>	
		<th>Jenis Kelamin</th>
		<th>:</th>
		<td><?php echo $guru['jk_guru'] ?></td>
	</tr>
	<tr>	
		<th>Agama</th>
		<th>:</th>
		<td><?php echo $guru['agama_guru'] ?></td>
	</tr>
	<tr>	
		<th>Pendidikan Guru</th>
		<th>:</th>
		<td><?php echo $guru['pendidikan_guru'] ?></td>
	</tr>
	<tr>	
		<th>Nomor Telpon</th>
		<th>:</th>
		<td><?php echo $guru['notelp_guru'] ?></td>
	</tr>
	<tr>	
		<th>Foto Guru</th>
		<th>:</th>
		<td>
			<img src="<?php echo base_url("assets/img/guru/".$guru['foto_guru']) ?>" width="150px">
		</td>
	</tr>
	<tr>	
		<th>Username Guru</th>
		<th>:</th>
		<td><?php echo $guru['username_guru'] ?></td>
	</tr>
	<tr>	
		<th>Password Guru</th>
		<th>:</th>
		<td><?php echo $guru['password_guru'] ?></td>
	</tr>
</table>
<a href="<?php echo base_url("guru/profil/ubah_profil") ?>" class="btn btn-warning">Ubah</a>
<a href="<?php echo base_url("guru/profil/ubah_password") ?>" class="btn btn-info">Ubah Password</a>