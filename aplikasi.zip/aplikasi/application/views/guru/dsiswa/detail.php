<h3 style="font-size: 20px; font-style: bold;" >KETERANGAN TENTANG DIRI ANAK DIDIK</h3>
<table width="100%" class="text-left">	
	<tr>
		<td width="3%">1.</td>
		<th width="25%" class="text-left">Nama Peserta Didik</th>
		<th width="1%">:</th>
		<td><?php echo $siswa['nama_siswa'] ?></td>
	</tr>
	<tr>
		<td>2.</td>	
		<th class="text-left">Nomor Induk Siswa</th>
		<th>:</th>
		<td><?php echo $siswa['nis_siswa'] ?></td>
	</tr>
	<tr>
		<td>3.</td>	
		<th class="text-left">Tempat/Tanggal Lahir</th>
		<th>:</th>
		<td><?php echo $siswa['tempat_lahir_siswa'].", ".tanggal_indonesia($siswa['tanggal_lahir_siswa']) ?></td>
	</tr>
	<tr>
		<td>4.</td>	
		<th>Alamat</th>
		<th>:</th>
		<td><?php echo $siswa['alamat_siswa'] ?></td>
	</tr>
	<tr>
		<td>5.</td>	
		<th>Jenis Kelamin</th>
		<th>:</th>
		<td><?php echo $siswa['jk_siswa'] ?></td>
	</tr>
	<tr>
		<td>6.</td>	
		<th>Nomor Telpon</th>
		<th>:</th>
		<td><?php echo $siswa['notelp_siswa'] ?></td>
	</tr>
	<tr>
		<td>7.</td>	
		<th>Sekolah Asal</th>
		<th>:</th>
		<td><?php echo $siswa['sekolah_asal']?>  
		<!-- <?php  if(isset($siswa[$value['id_siswa']]) AND $siswa[$value['id_siswa']]['sekolah_asal']=='Hadir') ?> -->
	</td>
</tr>
<tr>
	<td>8.</td>	
	<th>Agama</th>
	<th>:</th>
	<td><?php echo $siswa['agama_siswa'] ?></td>
</tr>
	<!-- <tr>
		<td>9.</td>	
		<th>Foto Siswa</th>
		<th>:</th>
		<td>
			<img src="<?php echo base_url("assets/img/siswa/".$siswa['foto_siswa']) ?>" width="100px">
		</td>
	</tr> -->
	<tr>
		<td>9.</td>	
		<th>Nama Orang Tua</th>
		<th></th>
		<td></td>
	</tr>
	<tr>
		<td></td>	
		<th>b. Ayah Siswa</th>
		<th>:</th>
		<td><?php echo $siswa['ayah_siswa'] ?></td>
	</tr>
	<tr>
		<td></td>	
		<th>b. Ibu Siswa</th>
		<th>:</th>
		<td><?php echo $siswa['ibu_siswa'] ?></td>
	</tr>
	<tr>
		<td>10.</td>	
		<th>No Telp Orang Tua</th>
		<th></th>
		<td></td>
	</tr>
	<tr>
		<td></td>	
		<th>a. No Telp Ayah</th>
		<th>:</th>
		<td><?php echo $siswa['notelp_ayah'] ?></td>
	</tr>
	<tr>
		<td></td>	
		<th>b. No Telp Ibu</th>
		<th>:</th>
		<td><?php echo $siswa['notelp_ibu'] ?></td>
	</tr>
	<!-- <tr>
		<td>12.</td>	
		<th>Pendidikan Orang Tua</th>
		<th></th>
		<td></td>
	</tr>
	<tr>
		<td></td>	
		<th>a. Pendidikan Ayah</th>
		<th>:</th>
		<td><?php echo $siswa['pendidikan_ayah'] ?></td>
	</tr>
	<tr>
		<td></td>	
		<th>b. Pendidikan Ibu</th>
		<th>:</th>
		<td><?php echo $siswa['pendidikan_ibu'] ?></td>
	</tr> -->
	<tr>
		<td>11.</td>	
		<th>Pekerjaan Orang Tua</th>
		<th></th>
		<td></td>
	</tr>
	<tr>
		<td></td>	
		<th>a. Kerja Ayah</th>
		<th>:</th>
		<td><?php echo $siswa['kerja_ayah'] ?></td>
	</tr>
	<tr>
		<td></td>	
		<th>b. Kerja Ibu</th>
		<th>:</th>
		<td><?php echo $siswa['kerja_ibu'] ?></td>
	</tr>
	<tr>
		<td></td>	
		<th>Username Siswa</th>
		<th>:</th>
		<td><?php echo $siswa['username_siswa'] ?></td>
	</tr>
<!-- 	<tr>
		<td></td>	
		<th>Password Siswa</th>
		<th>:</th>
		<td><?php echo $siswa['password_siswa'] ?></td>
	</tr> -->
	<tr>
		<td></td>
		<td>
			<div style="margin: 20px; height: 205px; width: 154px; border: 1px solid black; padding: auto;"><p style="text-align: center; padding-top: 10px;">3x4</p></div>
		</td>
		<td></td>
		<td>
			<p>Yogyakarta, <?php echo tanggal_indonesia(date("Y-m-d")) ?></p>
			<p style="margin-bottom: 100px">Kepala Sekolah</p>
			<p><u><?php echo $kepala_sekolah['nama_kepala_sekolah'] ?></u></p>
			<p>NIP. <?php echo $kepala_sekolah['nip_kepala_sekolah'] ?></p>
		</td>
	</tr>
</table>