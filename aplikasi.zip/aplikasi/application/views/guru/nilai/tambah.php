<h3>TAMBAH NILAI SISWA</h3>


<form>
	<div class="row">
		<div class="col-xs-6 col-md-4">
			<label></label>
			<select>
				<option>Pilih Kelas</option>
			</select>
		</div>	

		<div  class="col-xs-6 col-md-4">
			<label></label>
			<select>
				<option>Pilih Mata Pelajaran</option>
			</select>
		</div>	

		<div class="col-xs-6 col-md-4">
			<label></label>
			<select>
				<option>Pilih Mata Pelajaran</option>
			</select>
		</div>	

		<div class="col-xs-6 col-md-4">
			<label></label>
			<select>
				<option>Pilih Mata Pelajaran</option>
			</select>
		</div>	
	</div>
</form>
<br>
<br>
<div class="table table-responsive">

	<table class="table table-striped" id="thetable">
		<thead>
			<tr>
				<th>No</th>
				<th>NIS</th>
				<th>Nama Siswa</th>
				<th>Tugas</th>
				<th>UTS</th>
				<th>UAS</th>
				<th>Praktek</th>
				<th>Aksi</th>
			</tr>
		</thead>
		<tbody>

		</tbody>
	</table>
</div>	