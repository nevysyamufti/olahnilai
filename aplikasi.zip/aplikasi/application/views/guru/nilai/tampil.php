<h3>PENILAIAN MATA PELAJARAN</h3>
<hr>

<form class="form-inline">
	<div class="form-group">
		<select class="form-control" name="id_kelas" onchange="submit()">
			<option value="">Pilih Kelas</option>
			<?php foreach ($kelas as $key => $value): ?> 
				<option value="<?php echo $value['id_kelas'] ?>" <?php if($value['id_kelas']==$id_kelas){echo "selected";} ?>><?php echo $value['nama_kelas']." - ".$value['tingkat_kelas'] ?></option>
			<?php endforeach ?>
		</select>
	</div>

	<div class="form-group">
		<select class="form-control" name="id_mapel" onchange="submit()">
			<option value="">Pilih Mapel</option>
			<?php foreach ($mapel as $key => $value): ?> 
				<option value="<?php echo $value['id_mapel'] ?>" <?php if($value['id_mapel']==$id_mapel){echo "selected";} ?>><?php echo $value['nama_mapel'] ?></option>
			<?php endforeach ?>
		</select>
	</div>	

	<div class="form-group">
		<select class="form-control" name="id_semester" onchange="submit()">
			<option value="">Pilih Semester</option>
			<?php foreach ($semester as $key => $value): ?> 
				<option value="<?php echo $value['id_semester'] ?>" <?php if($value['id_semester']==$id_semester){echo "selected";} ?>><?php echo $value['nama_semester'] ?></option>
			<?php endforeach ?>
		</select>
	</div>

	<div class="form-group">
		<button class="btn btn-primary">Pilih</button>
	</div>
</form>

<form method="post">
	<div class="table table-responsive">
		<table class="table table-bordered" id="thetable">
			<thead>
				<tr>
					<th>No</th>
					<th>NIS</th>
					<th>Nama Siswa</th>
					<th>Tugas</th>
					<th>UTS</th>
					<th>UAS</th>
					<th>Praktek</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($siswa as $key => $value): ?>
					<tr>
						<td><?php echo $key+1 ?></td>
						<td><?php echo $value['nis_siswa'] ?></td>
						<td><?php echo $value['nama_siswa'] ?></td>
						<td>
							<input type="number" name="nilai[<?php echo $value['id_siswa'] ?>][nilai_tugas]" class="form-control" value="<?php if(isset($nilai[$value['id_siswa']])){echo $nilai[$value['id_siswa']]['nilai_tugas'];} ?>" <?php if($id_semester!=$semester_aktif['id_semester'] OR tahun_aktif()!=$tahun_aktif['id_tahun_ajaran']){echo "readonly";} ?>>
						</td>
						<td>
							<input type="number" name="nilai[<?php echo $value['id_siswa'] ?>][nilai_uts]" class="form-control" value="<?php if(isset($nilai[$value['id_siswa']])){echo $nilai[$value['id_siswa']]['nilai_uts'];} ?>" <?php if($id_semester!=$semester_aktif['id_semester'] OR tahun_aktif()!=$tahun_aktif['id_tahun_ajaran']){echo "readonly";} ?>>
						</td>
						<td>
							<input type="number" name="nilai[<?php echo $value['id_siswa'] ?>][nilai_uas]" class="form-control" value="<?php if(isset($nilai[$value['id_siswa']])){echo $nilai[$value['id_siswa']]['nilai_uas'];} ?>" <?php if($id_semester!=$semester_aktif['id_semester'] OR tahun_aktif()!=$tahun_aktif['id_tahun_ajaran']){echo "readonly";} ?>>
						</td>
						<td>
							<input type="number" name="nilai[<?php echo $value['id_siswa'] ?>][nilai_praktek]" class="form-control" value="<?php if(isset($nilai[$value['id_siswa']])){echo $nilai[$value['id_siswa']]['nilai_praktek'];} ?>" <?php if($id_semester!=$semester_aktif['id_semester'] OR tahun_aktif()!=$tahun_aktif['id_tahun_ajaran']){echo "readonly";} ?>>
						</td>
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
	<div class="form-group">
		<button class="btn btn-primary"> Simpan </button>
	</div>
</form>