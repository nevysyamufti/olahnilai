<h3>PENILAIAN ABSENSI</h3>

<!-- untuk memberi notifikasi bahwa bukan wali kelas -->
 <?php if (empty($siswa)): ?>
 	<div class="alert alert-info">Anda Bukan Wali Kelas</div>
 <?php else: ?>

<form class="form-inline">
<div class="form-group">
	<label>Pilih tanggal absen</label>
	<input type="date" name="tanggal_absensi" class="form-control" value="<?php echo $tanggal_absensi ?>">
</div>

<div class="form-group">
	<button class="btn btn-primary"> Pilih </button>
</div>
</form>
<br>
<form method="post">
	<div class="table-responsive">
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>No</th>
					<th>NIS</th>
					<th>Nama</th>
					<th>Input Absensi</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($siswa as $key => $value): ?>
					<tr>
						<td><?php echo $key+1 ?></td>
						<td><?php echo $value['nis_siswa'] ?></td>
						<td><?php echo $value['nama_siswa'] ?></td>
						<td>
							<label class="radio-inline">
							<input type="radio" name="status_absensi[<?php echo $value['id_siswa_kelas'] ?>]" value="Hadir" checked='checked'<?php if(isset($absensi[$value['id_siswa_kelas']]) AND $absensi[$value['id_siswa_kelas']]['status_absensi']=='Hadir'){echo "checked";} ?>> Hadir
							</label>

							<label class="radio-inline">
								<input type="radio" name="status_absensi[<?php echo $value['id_siswa_kelas'] ?>]" value="Ijin" <?php if(isset($absensi[$value['id_siswa_kelas']]) AND $absensi[$value['id_siswa_kelas']]['status_absensi']=='Ijin'){echo "checked";} ?>> Ijin
							</label>

							<label class="radio-inline">
								<input type="radio" name="status_absensi[<?php echo $value['id_siswa_kelas'] ?>]" value="Sakit" <?php if(isset($absensi[$value['id_siswa_kelas']]) AND $absensi[$value['id_siswa_kelas']]['status_absensi']=='Sakit'){echo "checked";} ?>> Sakit
							</label>

							<label class="radio-inline">
								<input type="radio" name="status_absensi[<?php echo $value['id_siswa_kelas'] ?>]" value="Alpa" <?php if(isset($absensi[$value['id_siswa_kelas']]) AND $absensi[$value['id_siswa_kelas']]['status_absensi']=='Alpa'){echo "checked";} ?>> Alpa
							</label>
						</td>
<?php// if(isset($absensi[$value['id_siswa_kelas']]) AND $absensi[$value['id_siswa_kelas']]['status_absensi']=='Ijin')?>
					</tr>
				<?php endforeach ?>
			</tbody>
		</table>
	</div>
	<div class="form-group">
		<button class="btn btn-primary"> Simpan Absensi </button>
	</div>
</form>
<?php endif ?>