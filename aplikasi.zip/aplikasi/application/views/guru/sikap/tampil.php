<h3>Penilaian Sikap</h3>
<hr>

<?php if (empty($siswa)): ?>
	<div class="alert alert-info">Anda Bukan Wali Kelas</div>
	<?php else: ?>

		<form method="post">
			<div class="table-responsive">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>No</th>
							<th>NIS</th>
							<th>Nama</th>
							<th>Keterangan Sikap</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ($siswa as $key => $value): ?>
							<tr>
								<td><?php echo $key+1 ?></td>
								<td><?php echo $value['nis_siswa'] ?></td>
								<td><?php echo $value['nama_siswa'] ?></td>
								<td>
									<label class="radio-inline">
										<input type="radio" name="keterangan_sikap[<?php echo $value['id_siswa_kelas'] ?>]"  value="Baik" checked='checked'<?php if(isset($sikap[$value['id_siswa_kelas']]) AND $sikap[$value['id_siswa_kelas']]['keterangan_sikap']=='Baik'){echo "checked";} ?>> Baik
									</label>

									<label class="radio-inline">
										<input type="radio" name="keterangan_sikap[<?php echo $value['id_siswa_kelas'] ?>]" value="Kurang" <?php if(isset($sikap[$value['id_siswa_kelas']]) AND $sikap[$value['id_siswa_kelas']]['keterangan_sikap']=='Kurang'){echo "checked";} ?>> Kurang
									</label>

									<label class="radio-inline">
										<input type="radio" name="keterangan_sikap[<?php echo $value['id_siswa_kelas'] ?>]" value="Cukup" <?php if(isset($sikap[$value['id_siswa_kelas']]) AND $sikap[$value['id_siswa_kelas']]['keterangan_sikap']=='Cukup'){echo "checked";} ?>> Cukup
									</label>
								</td>
							</tr>
						<?php endforeach ?>
					</tbody>
				</table>
			</div>
			<div class="form-group">
				<button class="btn btn-primary"> Simpan Sikap </button>
			</div>
		</form>
		<?php endif ?>