</div>
		</div>

	</div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php echo base_url("assets/js/bootstrap.min.js") ?>"></script>

<script src="<?php echo base_url("assets/js/inadmin.js") ?>"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
	$(document).ready(function()
	{
    $('#thetable').DataTable();
	} );
</script>

<script src="<?php echo base_url("assets/ckeditor/ckeditor.js") ?>"></script>
<script>
	CKEDITOR.replace("theeditor");
</script>

<!--<script src="js/inadmin.js"></script>-->
</body>
</html>