<h3>DATA SISWA</h3>
<hr>
<div class="table-responsive">
	<table class="table table-bordered" id="thetable">
		<thead>
			<tr>
				<th>No</th>
				<th>Foto</th>
				<th>Nomor Induk Siswa</th>
				<th>Nama Siswa</th>
				<th>Nomor Telpon</th>
				<th>Status Siswa</th>
				<th>Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($siswa as $key => $value): ?>
				<tr>
					<td><?php echo $key+1 ?></td>
					<td>
						<img src="<?php echo base_url("assets/img/siswa/".$value['foto_siswa']) ?>" width="100px">
					</td>
					<td><?php echo $value['nis_siswa'] ?></td>
					<td><?php echo $value['nama_siswa'] ?></td>
					<td><?php echo $value['notelp_siswa'] ?></td>
					<td><?php echo $value['status_siswa'] ?></td>
					<td>
						<a href="<?php echo base_url("kepsek/lsiswa/detail/".$value['id_siswa']) ?>" class="btn btn-info">Detail</a>
						<!-- <a href="<?php echo base_url("admin/siswa/ubah/".$value['id_siswa']) ?>"class="btn btn-warning">Ubah</a>
						<a href="<?php echo base_url("admin/siswa/hapus/".$value['id_siswa']) ?>"class="btn btn-danger" onclick="return confirm('Apakah yakin dihapus ?')">Hapus</a> -->
					</td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>
	<!-- <div>
		<a href="<?php echo base_url("admin/siswa/tambah") ?>" class="btn btn-primary">Tambah</a>
	</div> -->
</div>