<h3>DATA GURU</h3>
<hr>
<div class="table-responsive">
<table class="table table-bordered" id="thetable">
		<thead>
			<tr>
				<th>No</th>
				<th>Foto</th>
				<th>Nomor Induk Pegawai</th>
				<th>Nama Guru</th>
				<th>Nomor Telpon</th>
				<th>Aksi</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($guru as $key => $value): ?>
				<tr>
					<td><?php echo $key+1 ?></td>
					<td>
						<img src="<?php echo base_url("assets/img/guru/".$value['foto_guru']) ?>" width="90px">
					</td>
					<td><?php echo $value['nip_guru'] ?></td>
					<td><?php echo $value['nama_guru'] ?></td>
					<td><?php echo $value['notelp_guru'] ?></td>
					<td>
						<a href="<?php echo base_url("kepsek/lguru/detail/".$value['id_guru']) ?>" class="btn btn-info">Detail</a>
						<!-- <a href="<?php echo base_url("admin/guru/ubah/".$value['id_guru']) ?>"class="btn btn-warning">Ubah</a>
						<a href="<?php echo base_url("admin/guru/hapus/".$value['id_guru']) ?>"class="btn btn-danger" onclick="return confirm('Apakah yakin dihapus ?')">Hapus</a> -->
					</td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>
	<!-- <div>
		<a href="<?php echo base_url("admin/guru/tambah") ?>" class="btn btn-primary">Tambah</a>
	</div> -->
</div>