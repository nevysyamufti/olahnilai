<h3>Halaman Rapor Siswa</h3>
<hr>
<div class="table-responsive">
	<table class="table table-bordered">
		<thead>
			<tr>
				<th>No</th>
				<th>NIS</th>
				<th>Nama Siswa</th>
				<th>Nilai Siswa</th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($siswa as $key => $value): ?>
				<tr>
					<td><?php echo $key+=1 ?></td>
					<td><?php echo $value['nis_siswa'] ?></td>
					<td><?php echo $value['nama_siswa'] ?></td>
					<td>
						<a href="<?php echo base_url("kepsek/lnilai/detail/".$value['id_siswa']) ?>">Nilai</a>
					</td>
				</tr>
			<?php endforeach ?>
		</tbody>
	</table>
</div>